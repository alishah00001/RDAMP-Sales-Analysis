```python
import pandas as pd
df = pd.read_excel(r'C:\Users\murta\Downloads\Ace Superstore Retail Dataset.xlsx')

```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order ID</th>
      <th>Order Date</th>
      <th>Order Mode</th>
      <th>Customer ID</th>
      <th>City</th>
      <th>Postal Code</th>
      <th>Country</th>
      <th>Region</th>
      <th>Product ID</th>
      <th>Product Name</th>
      <th>Category</th>
      <th>Sub-Category</th>
      <th>Sales</th>
      <th>Cost Price</th>
      <th>Quantity</th>
      <th>Discount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>BTC-245712</td>
      <td>2024-06-22</td>
      <td>Online</td>
      <td>LO028977</td>
      <td>Norton</td>
      <td>S8</td>
      <td>England</td>
      <td>NaN</td>
      <td>01JZ3N512GHNAJSF3HCCQ0PQYY</td>
      <td>Flavored Popcorn Mix</td>
      <td>Food - Snacks</td>
      <td>Gourmet Snacks</td>
      <td>2.99</td>
      <td>0.897</td>
      <td>4</td>
      <td>0.24</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NZR-891212</td>
      <td>2024-03-15</td>
      <td>In-Store</td>
      <td>OH046670</td>
      <td>West End</td>
      <td>DN36</td>
      <td>England</td>
      <td>East of England</td>
      <td>01JZ3N56DDVK7Y600QGH2M6T1X</td>
      <td>Olive Oil</td>
      <td>Food - Condiments</td>
      <td>Cooking Oils</td>
      <td>7.99</td>
      <td>2.397</td>
      <td>16</td>
      <td>0.32</td>
    </tr>
    <tr>
      <th>2</th>
      <td>TDN-811093</td>
      <td>2024-02-29</td>
      <td>Online</td>
      <td>FH015492</td>
      <td>Newtown</td>
      <td>RG20</td>
      <td>England</td>
      <td>East Midlands</td>
      <td>01JZ3N53A64TW72TVK28SMMXKX</td>
      <td>Children's Backpack</td>
      <td>Accessories</td>
      <td>Kids' Bags</td>
      <td>29.99</td>
      <td>8.997</td>
      <td>2</td>
      <td>0.09</td>
    </tr>
    <tr>
      <th>3</th>
      <td>MIX-746378</td>
      <td>2024-10-25</td>
      <td>In-Store</td>
      <td>ZZ015342</td>
      <td>East End</td>
      <td>BH21</td>
      <td>England</td>
      <td>North West</td>
      <td>01JZ3N572S4RVA29Y33YRWH174</td>
      <td>Honey Butter Popcorn</td>
      <td>Food - Snacks</td>
      <td>Gourmet Snacks</td>
      <td>2.99</td>
      <td>0.897</td>
      <td>4</td>
      <td>0.01</td>
    </tr>
    <tr>
      <th>4</th>
      <td>UGI-201465</td>
      <td>2024-08-18</td>
      <td>Online</td>
      <td>TV075977</td>
      <td>Seaton</td>
      <td>LE15</td>
      <td>England</td>
      <td>East Midlands</td>
      <td>01JZ3N52RT7CJNB27BFS6H8BF7</td>
      <td>Sliced Cucumbers</td>
      <td>Food - Produce</td>
      <td>Fresh Cut Vegetables</td>
      <td>1.29</td>
      <td>0.387</td>
      <td>11</td>
      <td>0.34</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>10995</th>
      <td>DSZ-011268</td>
      <td>2024-05-07</td>
      <td>In-Store</td>
      <td>WF009587</td>
      <td>Milton</td>
      <td>NG22</td>
      <td>England</td>
      <td>NaN</td>
      <td>01JZ3N5AW1CPFPMWWT33J6AGMW</td>
      <td>Cheddar Cheese Crackers</td>
      <td>Food - Snacks</td>
      <td>Savory Snacks</td>
      <td>2.29</td>
      <td>0.687</td>
      <td>4</td>
      <td>0.14</td>
    </tr>
    <tr>
      <th>10996</th>
      <td>CGM-940703</td>
      <td>2023-01-08</td>
      <td>Online</td>
      <td>BP009480</td>
      <td>London</td>
      <td>EC1V</td>
      <td>England</td>
      <td>London</td>
      <td>01JZ3NC7B86JEQRHTJTFX0FSGK</td>
      <td>Reusable Produce Bags Set</td>
      <td>Kitchen</td>
      <td>Eco-Friendly Kitchen Products</td>
      <td>14.99</td>
      <td>4.497</td>
      <td>7</td>
      <td>0.17</td>
    </tr>
    <tr>
      <th>10997</th>
      <td>HRH-890460</td>
      <td>2023-03-22</td>
      <td>In-Store</td>
      <td>ME002547</td>
      <td>Normanton</td>
      <td>LE15</td>
      <td>England</td>
      <td>North West</td>
      <td>01JZ3N5989NSCYRYH9AT9BA983</td>
      <td>Fitness Resistance Bands Set</td>
      <td>Fitness</td>
      <td>Strength Training Equipment</td>
      <td>34.99</td>
      <td>10.497</td>
      <td>8</td>
      <td>0.11</td>
    </tr>
    <tr>
      <th>10998</th>
      <td>IFZ-697340</td>
      <td>2024-09-27</td>
      <td>Online</td>
      <td>JQ001839</td>
      <td>Seaton</td>
      <td>LE15</td>
      <td>England</td>
      <td>South West</td>
      <td>01JZ3NC5FBR8J1HDZXW4XW5RH7</td>
      <td>Smartphone Tripod</td>
      <td>Photography</td>
      <td>Tripods &amp; Accessories</td>
      <td>29.99</td>
      <td>8.997</td>
      <td>19</td>
      <td>0.38</td>
    </tr>
    <tr>
      <th>10999</th>
      <td>LPN-893872</td>
      <td>2023-01-20</td>
      <td>In-Store</td>
      <td>DB076382</td>
      <td>Sutton</td>
      <td>CT15</td>
      <td>England</td>
      <td>North East</td>
      <td>01JZ3NC4DC77G1KN0YJGS764RP</td>
      <td>Gingerbread House Kit</td>
      <td>Food - Baking</td>
      <td>Baking Kits</td>
      <td>6.99</td>
      <td>2.097</td>
      <td>13</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>11000 rows × 16 columns</p>
</div>




```python
df.describe()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Order Date</th>
      <th>Sales</th>
      <th>Cost Price</th>
      <th>Quantity</th>
      <th>Discount</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>11000</td>
      <td>11000.000000</td>
      <td>11000.000000</td>
      <td>11000.000000</td>
      <td>10027.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2024-02-28 06:43:04.145454336</td>
      <td>27.393995</td>
      <td>9.032361</td>
      <td>10.491273</td>
      <td>0.172086</td>
    </tr>
    <tr>
      <th>min</th>
      <td>2023-01-01 00:00:00</td>
      <td>-0.100000</td>
      <td>-0.263000</td>
      <td>1.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2023-08-14 00:00:00</td>
      <td>3.990000</td>
      <td>1.197000</td>
      <td>5.000000</td>
      <td>0.070000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>2024-03-14 00:00:00</td>
      <td>12.140000</td>
      <td>3.897000</td>
      <td>11.000000</td>
      <td>0.160000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2024-09-12 06:00:00</td>
      <td>33.990000</td>
      <td>11.447000</td>
      <td>15.000000</td>
      <td>0.270000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2025-03-30 00:00:00</td>
      <td>900.990000</td>
      <td>359.996000</td>
      <td>20.000000</td>
      <td>0.400000</td>
    </tr>
    <tr>
      <th>std</th>
      <td>NaN</td>
      <td>47.209430</td>
      <td>16.198765</td>
      <td>5.758632</td>
      <td>0.113953</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info
```




    <bound method DataFrame.info of          Order ID Order Date Order Mode Customer ID       City Postal Code  \
    0      BTC-245712 2024-06-22     Online    LO028977     Norton          S8   
    1      NZR-891212 2024-03-15   In-Store    OH046670   West End        DN36   
    2      TDN-811093 2024-02-29     Online    FH015492    Newtown        RG20   
    3      MIX-746378 2024-10-25   In-Store    ZZ015342   East End        BH21   
    4      UGI-201465 2024-08-18     Online    TV075977     Seaton        LE15   
    ...           ...        ...        ...         ...        ...         ...   
    10995  DSZ-011268 2024-05-07   In-Store    WF009587     Milton        NG22   
    10996  CGM-940703 2023-01-08     Online    BP009480     London        EC1V   
    10997  HRH-890460 2023-03-22   In-Store    ME002547  Normanton        LE15   
    10998  IFZ-697340 2024-09-27     Online    JQ001839     Seaton        LE15   
    10999  LPN-893872 2023-01-20   In-Store    DB076382     Sutton        CT15   
    
           Country           Region                  Product ID  \
    0      England              NaN  01JZ3N512GHNAJSF3HCCQ0PQYY   
    1      England  East of England  01JZ3N56DDVK7Y600QGH2M6T1X   
    2      England    East Midlands  01JZ3N53A64TW72TVK28SMMXKX   
    3      England       North West  01JZ3N572S4RVA29Y33YRWH174   
    4      England    East Midlands  01JZ3N52RT7CJNB27BFS6H8BF7   
    ...        ...              ...                         ...   
    10995  England              NaN  01JZ3N5AW1CPFPMWWT33J6AGMW   
    10996  England           London  01JZ3NC7B86JEQRHTJTFX0FSGK   
    10997  England       North West  01JZ3N5989NSCYRYH9AT9BA983   
    10998  England       South West  01JZ3NC5FBR8J1HDZXW4XW5RH7   
    10999  England       North East  01JZ3NC4DC77G1KN0YJGS764RP   
    
                           Product Name           Category  \
    0              Flavored Popcorn Mix      Food - Snacks   
    1                         Olive Oil  Food - Condiments   
    2               Children's Backpack        Accessories   
    3              Honey Butter Popcorn      Food - Snacks   
    4                  Sliced Cucumbers     Food - Produce   
    ...                             ...                ...   
    10995       Cheddar Cheese Crackers      Food - Snacks   
    10996     Reusable Produce Bags Set            Kitchen   
    10997  Fitness Resistance Bands Set            Fitness   
    10998             Smartphone Tripod        Photography   
    10999         Gingerbread House Kit      Food - Baking   
    
                            Sub-Category  Sales  Cost Price  Quantity  Discount  
    0                     Gourmet Snacks   2.99       0.897         4      0.24  
    1                       Cooking Oils   7.99       2.397        16      0.32  
    2                         Kids' Bags  29.99       8.997         2      0.09  
    3                     Gourmet Snacks   2.99       0.897         4      0.01  
    4               Fresh Cut Vegetables   1.29       0.387        11      0.34  
    ...                              ...    ...         ...       ...       ...  
    10995                  Savory Snacks   2.29       0.687         4      0.14  
    10996  Eco-Friendly Kitchen Products  14.99       4.497         7      0.17  
    10997    Strength Training Equipment  34.99      10.497         8      0.11  
    10998          Tripods & Accessories  29.99       8.997        19      0.38  
    10999                    Baking Kits   6.99       2.097        13       NaN  
    
    [11000 rows x 16 columns]>




```python
print(df.isnull().sum())
```

    Order ID           0
    Order Date         0
    Order Mode         0
    Customer ID        0
    City               0
    Postal Code        0
    Country          220
    Region          2811
    Product ID         0
    Product Name       0
    Category         198
    Sub-Category       0
    Sales              0
    Cost Price         0
    Quantity           0
    Discount         973
    dtype: int64
    


```python
#converting order of date to datetime method
df['Order Date']=pd.to_datetime(df['Order Date'])
print(df['Order Date'])
```

    0       2024-06-22
    1       2024-03-15
    2       2024-02-29
    3       2024-10-25
    4       2024-08-18
               ...    
    10995   2024-05-07
    10996   2023-01-08
    10997   2023-03-22
    10998   2024-09-27
    10999   2023-01-20
    Name: Order Date, Length: 11000, dtype: datetime64[ns]
    


```python
#As many regions are missing so I am gonna fill them with unknows
df['Region']=df['Region'].fillna('unknown')
print(df['Region'])
```

    0                unknown
    1        East of England
    2          East Midlands
    3             North West
    4          East Midlands
                  ...       
    10995            unknown
    10996             London
    10997         North West
    10998         South West
    10999         North East
    Name: Region, Length: 11000, dtype: object
    


```python
# As 973 discount column is empty so I assume it as 0 discount
df['Discount']=df['Discount'].fillna(0.0)
print(df['Discount'])
```

    0        0.24
    1        0.32
    2        0.09
    3        0.01
    4        0.34
             ... 
    10995    0.14
    10996    0.17
    10997    0.11
    10998    0.38
    10999    0.00
    Name: Discount, Length: 11000, dtype: float64
    


```python
#Maximum data is from England
import matplotlib.pyplot as plt
import seaborn as sns
sns.histplot(df['Country'])
plt.title('Country')
```




    Text(0.5, 1.0, 'Country')




    
![png](output_8_1.png)
    



```python
#Here is the logic where we can see the countryu name by using postcode and regions.
import pandas as pd

# Show all columns and rows
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)

# Filter the rows
missing_country_with_region = df[df['Country'].isna() & df['Region'].notna()]

# Display all columns for those rows
print(missing_country_with_region)

```

             Order ID Order Date Order Mode Customer ID        City Postal Code  \
    12     MQD-548505 2024-11-04     Online    LT073005      London         W1F   
    79     HWI-435693 2024-08-01   In-Store    JQ000431  Whitchurch        BS14   
    238    ADB-528290 2024-01-19     Online    KT034728     Newport        NR29   
    266    WKW-425139 2024-08-06     Online    WI076001      Pentre         SY4   
    341    NCR-659401 2024-08-26   In-Store    TI096309  Birmingham         B40   
    364    POV-954028 2024-09-11     Online    BQ020024      Norton          S8   
    464    HOO-423053 2024-07-04     Online    KM028653     Twyford        LE14   
    558    LSM-655824 2024-12-23     Online    AX035056    Brampton        NR34   
    637    JXB-975100 2024-01-24   In-Store    WC070179        Ford        GL54   
    729    KJU-134829 2024-05-23   In-Store    YL039169   Edinburgh         EH9   
    799    DHC-099562 2024-04-23   In-Store    FY080136     Twyford        LE14   
    912    TRY-412778 2024-03-05     Online    RC069836       Leeds         LS6   
    916    PIP-528358 2024-06-29     Online    QU055720   Craigavon        BT66   
    998    SEW-639743 2024-06-26     Online    WI001306    Bradford         BD7   
    1003   UIB-003832 2024-06-09   In-Store    MG006726       Eaton        DN22   
    1198   ANR-205863 2024-09-08     Online    MG053337      London        EC3M   
    1295   KZS-059602 2024-09-09   In-Store    IU070986    Kingston        DT10   
    1333   OVJ-876931 2024-09-26   In-Store    II051569   Middleton        LE16   
    1355   VYY-053421 2024-06-01   In-Store    LG018760     Kinloch        PH43   
    1449   IEP-246785 2024-02-01   In-Store    NJ058700      Halton         LS9   
    1538   VBA-777656 2024-12-20     Online    MP053511     Preston         PR1   
    1614   WLS-986261 2024-04-01     Online    LE096161    Kingston        DT10   
    1671   WXP-335322 2024-08-12   In-Store    FC077811      London        WC1B   
    1697   LTQ-445303 2024-10-20   In-Store    MJ023223  Church End          N3   
    1713   BEJ-564218 2024-01-30   In-Store    VG036239      Horton        BS37   
    1738   IBA-201049 2024-02-06     Online    ET068053     Tullich        AB55   
    1852   SCS-132777 2024-11-30     Online    KA083039  Birmingham         B12   
    1905   ZBF-145365 2024-01-12   In-Store    WW015228      Ashley        SN13   
    1937   ZSK-807269 2024-08-17   In-Store    RV094330     Glasgow          G4   
    1979   LNZ-639756 2024-06-02   In-Store    LQ030733  Church End          N3   
    1997   PND-180433 2024-12-22   In-Store    PA050829      Seaton        LE15   
    2000   DQX-946455 2025-01-20     Online    KP075796      Norton          S8   
    2051   NXZ-501508 2025-02-03   In-Store    VH068058  Birmingham         B40   
    2139   VBB-278946 2025-03-21   In-Store    DO001772  Stapleford         LN6   
    2195   KCT-526859 2025-01-14   In-Store    CI029431      Milton        NG22   
    2322   LLR-236394 2025-03-29     Online    CS062668   Newbiggin        NE46   
    2487   ENC-678237 2025-02-14   In-Store    VZ013231   Sheffield          S1   
    2511   QXM-174224 2025-03-06   In-Store    CS060883   Liverpool         L33   
    2512   PUJ-913917 2025-03-18     Online    FB057385       Aston         TF6   
    2582   MRL-550661 2025-01-14     Online    XT003630        Ford        GL54   
    2589   RPT-644547 2025-01-30   In-Store    OX028733      Seaton        LE15   
    2615   CMN-363041 2025-01-31   In-Store    ZX011281      London        SW1E   
    2648   KFM-576372 2025-01-09     Online    DG084549      London        WC1B   
    2656   IXG-243078 2025-02-03     Online    ZJ097568      Newton        NG34   
    2674   HZG-160569 2025-01-18     Online    HU076125     Twyford        LE14   
    2692   GTG-129367 2025-02-11     Online    NS050281    Burnside        EH52   
    2699   QEL-364465 2025-03-25   In-Store    HH019414      Horton        BS37   
    2708   LDL-164981 2025-01-24     Online    IR005341    Kingston        DT10   
    2808   ZOW-431120 2025-03-28     Online    AC032117      Milton        NG22   
    2927   QVB-513402 2025-03-13   In-Store    TU039036   Liverpool         L33   
    2941   HDG-394302 2025-01-24   In-Store    ES011889    Brampton        NR34   
    3005   PVE-486005 2024-08-05   In-Store    UZ041116      Sutton        CT15   
    3041   WJX-702657 2024-11-19   In-Store    HS079253   Normanton        LE15   
    3150   SHW-553108 2024-04-01     Online    EE091486    Buckland        CT16   
    3215   WAK-299537 2024-02-29   In-Store    QJ021663     Langley         SG4   
    3224   ZGI-126976 2024-01-31     Online    FI092285      London         W1F   
    3250   OQF-377616 2024-12-20     Online    KZ037486      Seaton        LE15   
    3294   NOT-219674 2024-06-25     Online    ME002547      Hatton        CV35   
    3370   BNZ-951181 2024-03-01     Online    KF095712      Wirral        CH48   
    3387   ATO-145557 2024-09-17   In-Store    CV078630      Sutton         RH5   
    3515   YSE-574831 2024-09-22   In-Store    ZF096387    Whitwell        DL10   
    3581   YYB-723660 2024-12-04   In-Store    OW060749        Dean         OX7   
    3591   HAZ-354603 2024-06-01   In-Store    SD004526     Belfast         BT2   
    3620   CZU-930114 2024-12-14     Online    NY046491  Manchester         M14   
    3767   LAA-107238 2024-05-28   In-Store    RI080002      Linton        BD23   
    3915   ALD-669759 2024-02-15   In-Store    QI022646        Dean         OX7   
    3968   KBT-759794 2024-08-19     Online    MT040981      Halton         LS9   
    3976   PRN-066256 2024-04-09     Online    KZ002772     Tullich        AB55   
    3985   DMH-876102 2024-06-28   In-Store    CI047459      Halton         LS9   
    4030   XZY-932707 2024-10-21     Online    MR095329     Preston         PR1   
    4160   QMX-241048 2024-09-20     Online    RF084560   Edinburgh         EH9   
    4207   HVM-144278 2024-05-01   In-Store    WB009533   Normanton        LE15   
    4214   HXD-470397 2024-11-17     Online    HS044934    Kingston        DT10   
    4322   QUR-008385 2024-02-23     Online    RP074096  Whitchurch        BS14   
    4332   IZP-886999 2024-11-10     Online    NH018056    East End        BH21   
    4405   JHK-960248 2024-06-23   In-Store    RV083774     Marston        ST20   
    4406   IYE-363002 2024-04-03     Online    OX048387       Eaton        DN22   
    4435   VYQ-823946 2024-05-12   In-Store    OI095558  Church End         CB4   
    4485   MKW-757577 2024-11-24   In-Store    GZ035351      Merton        SW19   
    4516   NYA-222349 2024-04-12     Online    YC088606        Ford        GL54   
    4524   FRC-390121 2024-06-12     Online    MX008191      Norton          S8   
    4674   MTR-530779 2024-03-30     Online    DE093942  Manchester         M14   
    4676   ABN-215004 2024-09-27     Online    AQ015573      Ashley        SN13   
    4710   MQZ-125493 2024-04-12     Online    VO025473   Sheffield         S33   
    4945   TBJ-715106 2024-04-04   In-Store    RA036163    Aberdeen        AB39   
    4968   KZA-200509 2024-12-14     Online    ZI065793   Craigavon        BT66   
    5011   RYV-318355 2023-01-25   In-Store    CN044542  Church End         CB4   
    5067   CLE-955281 2023-04-18   In-Store    JY078378      London        SW1E   
    5102   FIM-331647 2023-12-03     Online    LE047809   Sheffield         S33   
    5134   HVX-714496 2023-08-26     Online    UT094280      Merton        SW19   
    5135   XLA-125632 2023-10-18   In-Store    DU053934       Eaton        DN22   
    5147   NGA-354380 2023-05-25   In-Store    GF083063   Middleton        LE16   
    5153   PCB-788913 2023-06-21   In-Store    ZG005436       Leeds         LS6   
    5400   XKH-761429 2023-12-05     Online    JW093275    Charlton        OX12   
    5518   JSG-241074 2023-10-09     Online    OK062011    Burnside        EH52   
    5555   OCJ-846829 2023-11-22   In-Store    DI067107      London        WC2H   
    5625   UZM-994139 2023-01-20   In-Store    BW040945  Birmingham         B12   
    5644   GLG-377242 2023-07-08     Online    VN096733       Upton         WF9   
    5743   NAA-958351 2023-11-18   In-Store    MI051892      Newton        NG34   
    5771   GHC-169929 2023-06-30   In-Store    QD096193      Hatton        CV35   
    5820   PSM-225744 2023-01-10     Online    IR005341   Sheffield         S33   
    5835   MPB-809068 2023-06-02   In-Store    TK000744      Newton         IV1   
    5904   ASG-705978 2023-06-25     Online    RO013242  Birmingham         B12   
    5929   LYR-689375 2023-03-16   In-Store    RV066355   Liverpool         L74   
    5988   XUD-571749 2023-11-04     Online    JW093275    Whitwell        DL10   
    6099   ZSA-051216 2023-12-21   In-Store    YV012185    West End        DN36   
    6148   LKJ-383680 2023-09-23     Online    QM000750    Aberdeen        AB39   
    6157   XGE-103525 2023-11-09   In-Store    DM054202    Burnside        EH52   
    6217   OTW-793095 2023-03-03   In-Store    BK071778      London        WC1B   
    6315   BPF-060170 2023-11-16   In-Store    XZ039413      Milton        AB56   
    6346   KPA-914950 2023-06-09     Online    GQ006805     Bristol        BS41   
    6380   NWU-152895 2023-05-16     Online    TX016353      Denton         M34   
    6403   VWZ-562480 2023-03-18   In-Store    UK043146   Craigavon        BT66   
    6419   NVQ-328064 2023-10-06   In-Store    QA049932  Birmingham         B12   
    6438   UOY-648583 2023-08-18     Online    WW057085    Aberdeen        AB39   
    6439   INK-105579 2023-11-15   In-Store    UE005686      Pentre         SY4   
    6539   QZY-915347 2023-05-15   In-Store    KG064314   Newbiggin        NE46   
    6587   DNG-908793 2023-08-23   In-Store    CU022928  Manchester         M14   
    6614   AMY-993195 2023-02-15     Online    AX023223  Church End          N3   
    6639   QOE-522833 2023-11-19   In-Store    RI031264    Bradford         BD7   
    6790   GGD-230954 2023-10-11     Online    FX049665    Brampton        NR34   
    6799   YZR-310436 2023-11-12   In-Store    XN095451      Thorpe        BD23   
    6873   FMG-133367 2023-02-15   In-Store    PD039339    Burnside        EH52   
    6907   KEC-694441 2023-07-31   In-Store    PI043259   Liverpool         L33   
    6930   ZFY-473902 2023-10-05     Online    CO084555      London        EC1V   
    6951   CEQ-296286 2023-03-21   In-Store    XZ039413  Birmingham         B40   
    7038   BAE-918331 2023-06-12     Online    WP034593     Kirkton        KW10   
    7199   LMN-465588 2023-11-18   In-Store    KO035342     Twyford        LE14   
    7210   PMV-401357 2023-11-11     Online    JO026492      London        WC1B   
    7252   DMS-193998 2023-03-05     Online    KM058384      Norton        NN11   
    7256   CUQ-541965 2023-04-18     Online    UO091520   Craigavon        BT66   
    7328   VKI-406219 2023-07-30     Online    XC022001       Aston         TF6   
    7378   UAQ-377712 2023-05-08     Online    QJ084755       Aston         TF6   
    7383   TLC-397413 2023-01-14   In-Store    YR079674      London        WC1B   
    7385   CMM-146425 2023-01-14   In-Store    QV077520     Wootton         NN4   
    7402   IHF-748301 2023-04-26     Online    VY000998     Swindon         SN1   
    7442   HFN-407049 2023-08-03     Online    TB042465       Upton         WF9   
    7545   BIF-298718 2023-09-12   In-Store    AV098482      Seaton        LE15   
    7576   QUE-173764 2023-10-29     Online    JC078143      Merton        SW19   
    7623   TCQ-889378 2023-07-11   In-Store    YR075422     Newport        NR29   
    7635   OUI-992745 2023-05-05   In-Store    XL046143     Newport        NR29   
    7668   OLB-358268 2023-01-08     Online    PQ058676     Swindon         SN1   
    7687   QXD-995127 2023-11-18   In-Store    CW018722   Normanton        LE15   
    7762   RCQ-617965 2023-01-08     Online    CW016254      Pentre         SY4   
    7775   EUF-815005 2023-10-17   In-Store    IS056610      Horton        BS37   
    7795   YQH-596426 2023-01-01   In-Store    ET028434      Walton        CV35   
    7850   BJJ-523279 2023-05-24     Online    EC090021       Leeds         LS6   
    7876   TMQ-033141 2023-01-04     Online    KT055492     Marston        ST20   
    7899   AGE-479327 2023-03-28   In-Store    ZC082059  Birmingham         B12   
    7916   LRF-838205 2023-04-25     Online    AI087863   Liverpool         L33   
    8035   TRR-603399 2023-06-17   In-Store    KJ061948      Horton        BS37   
    8093   VCI-061112 2023-06-06   In-Store    RS025554  Church End         CB4   
    8094   YBS-824241 2023-04-29     Online    US038719      Sutton         RH5   
    8106   VBW-999626 2023-02-04     Online    QM006843      Halton         LS9   
    8137   LXN-535316 2023-06-14   In-Store    FC025577    Bradford         BD7   
    8328   TSK-054690 2023-10-20     Online    ZV068041      Denton         M34   
    8431   LJY-617522 2023-05-10   In-Store    VC036954       Aston         TF6   
    8499   LFV-681624 2023-11-13   In-Store    CF065346      London        WC2H   
    8507   BLI-719704 2023-10-08   In-Store    KR081746     Preston         PR1   
    8543   XJJ-146740 2023-12-09   In-Store    XH025814      Halton         LS9   
    8583   VML-002732 2023-01-27   In-Store    LR077329      Newton        NG34   
    8657   GEQ-396502 2023-07-30   In-Store    JB029525      London        EC3M   
    8675   PXW-365645 2023-04-15   In-Store    LA028763    Bradford         BD7   
    8691   ETQ-236315 2023-04-28   In-Store    OA062579       Eaton        DN22   
    8715   RUG-846084 2023-11-28   In-Store    WY016116  Birmingham         B12   
    8765   ADS-226814 2023-02-05   In-Store    KB036902      London        WC2H   
    8797   YDI-513213 2023-09-09   In-Store    HR020563      Sutton         RH5   
    8807   ACM-495414 2023-04-23   In-Store    SL086802     Wootton         NN4   
    8843   YUU-484054 2023-12-03   In-Store    MC002765      Linton        BD23   
    8936   HBQ-643361 2023-11-04     Online    QL031793      Seaton        LE15   
    8941   PCS-305970 2023-09-20   In-Store    DT071239    Kingston        DT10   
    8978   VQT-307507 2023-01-30     Online    TQ072775      Wirral        CH48   
    8988   GHU-345640 2023-08-12     Online    NH080945       Aston         TF6   
    9053   MUE-890820 2024-07-15   In-Store    HL011929      Denton         M34   
    9065   YIS-609865 2024-01-30     Online    PW074537       Upton         WF9   
    9104   OCQ-397338 2024-06-08   In-Store    MT015986        Dean         OX7   
    9106   VPC-545463 2024-11-15   In-Store    RZ076572   Middleton        LE16   
    9172   HFI-522902 2024-10-20   In-Store    MA036960      London        SW1E   
    9200   XGG-030111 2025-01-19     Online    ID089240     Wootton         NN4   
    9265   WLM-417074 2025-01-22   In-Store    JF074393     Newport        NR29   
    9359   YRO-201903 2024-10-11     Online    CI094569        Dean         OX7   
    9424   DWH-650212 2025-03-18     Online    IR090467    Brampton        NR34   
    9486   EQI-579965 2024-01-31   In-Store    GU043275      Pentre         SY4   
    9534   KXA-188328 2024-09-01     Online    IL069417   Newbiggin        NE46   
    9574   GCA-662459 2024-04-09     Online    QX050839      Linton        BD23   
    9643   FJB-382818 2025-01-21   In-Store    NC044531      Merton        SW19   
    9644   BJH-829905 2024-11-03   In-Store    PJ007525     Preston         PR1   
    9653   OAV-249704 2024-04-08   In-Store    JC078143     Newport        NR29   
    9697   MHA-325272 2024-05-08     Online    NB042671      Merton        SW19   
    9723   MJN-688136 2025-01-22   In-Store    JU003803   Liverpool         L74   
    9726   DVC-916640 2024-12-04     Online    HV092307        Ford        GL54   
    9747   XGA-761266 2024-04-30     Online    EP091516      Denton         M34   
    9766   THJ-208879 2024-07-31     Online    LS079402        Dean         OX7   
    9830   RDU-141875 2024-11-19   In-Store    PI058311      Sutton        CT15   
    9843   UCL-993299 2024-05-04     Online    VO004755      London        SW1E   
    9870   ASB-107561 2024-12-11     Online    VX036428      London        WC2H   
    9902   VDN-957294 2024-01-01   In-Store    IY088933      Norton          S8   
    9936   JUZ-826614 2024-04-01     Online    ST035959        Ford        GL54   
    10045  YGF-533390 2023-10-06   In-Store    AF014335    Burnside        EH52   
    10061  WLR-146489 2023-08-16   In-Store    BN060023       Leeds         LS6   
    10181  APK-675634 2023-03-28   In-Store    WP034593     Newtown        RG20   
    10206  BRS-920066 2023-04-04     Online    SP051385    Bradford         BD7   
    10254  IXQ-581636 2024-10-14     Online    YZ017964   Liverpool         L33   
    10373  PYQ-775769 2024-03-21   In-Store    NC044531      London        EC3M   
    10406  TNR-129419 2024-04-20     Online    KZ002772       Upton         WF9   
    10508  GLQ-014662 2023-02-19     Online    SC094075    East End        BH21   
    10527  HHN-571939 2023-12-18   In-Store    BS070916  Whitchurch        BS14   
    10607  TBQ-409574 2024-04-06   In-Store    LG075926   Newbiggin        NE46   
    10635  NQC-089613 2023-03-20   In-Store    RE017445    Bradford         BD7   
    10643  IWY-454825 2023-05-28   In-Store    AV098482     Belfast         BT2   
    10663  BGI-421604 2024-02-23   In-Store    ZH091699      Linton        BD23   
    10706  NMX-569582 2024-06-09     Online    TB042465     Newtown        RG20   
    10723  ARU-447591 2023-04-28   In-Store    VC000359     Newtown        RG20   
    10727  FLE-699612 2023-01-06   In-Store    RW020820      Seaton        LE15   
    10733  NLS-955781 2024-04-04   In-Store    XC022001      Seaton        LE15   
    10753  IQV-186366 2024-06-09   In-Store    YP002686      Milton        NG22   
    10843  QLU-047515 2024-11-20   In-Store    JO021400     Belfast         BT2   
    10851  CEJ-417306 2024-03-05   In-Store    PU001485  Manchester         M14   
    10905  MHH-177948 2023-06-11   In-Store    IO065243      London        EC1V   
    10935  BOJ-207194 2024-07-20   In-Store    ET028434     Belfast         BT2   
    
          Country                    Region                  Product ID  \
    12        NaN             West Midlands  01JZ3N51PJSSC4680WPA4VCNFH   
    79        NaN             East Midlands  01JZ3N55H83PKNR5TH9H69YCE3   
    238       NaN                North West  01JZ3N56XPME9NKWFGZX3W09ND   
    266       NaN                South East  01JZ3N55YCPX0D3K6Y919H89GK   
    341       NaN             West Midlands  01JZ3N55NK7Z3Q1DJRSNBS8K8A   
    364       NaN                North East  01JZ3N52ACQV9R3408AQEWVMA2   
    464       NaN  Yorkshire and the Humber  01JZ3N55JMSRD208JZ79KFYNQY   
    558       NaN             West Midlands  01JZ3N56JGW5703P2DCNZSMNSC   
    637       NaN                    London  01JZ3N559ZYQSWPHX8MR50F80H   
    729       NaN                North East  01JZ3N54RADHKCYHWZNPVYF0NK   
    799       NaN             East Midlands  01JZ3N54VHK9Z3J7NJRA5ASZSW   
    912       NaN                    London  01JZ3N53J5FTP9096ZS78Y3PGF   
    916       NaN                South West  01JZ3N52NM0CHTTYCF1RSP0ZVT   
    998       NaN                South West  01JZ3N52BJR60NHTXRJM973WN8   
    1003      NaN                North West  01JZ3NT0W7CS0W3AFK08D40KY0   
    1198      NaN                    London  01JZ3NR6YQQW9YGWNDJJY9HAMQ   
    1295      NaN           East of England  01JZ3NR77XH2N21FN18ENJXQ5N   
    1333      NaN                South East  01JZ3NR78T607XN8MYTVSVSVAR   
    1355      NaN                North East  01JZ3NC9ZQKV7FDACKF9H8GRVV   
    1449      NaN           East of England  01JZ3NT56BTGVFRFZMAMWDH61J   
    1538      NaN           East of England  01JZ3NCATB7DPT7B8N67YKQEDG   
    1614      NaN                South West  01JZ3NR1JY7YRFR16GWKJJ9KM7   
    1671      NaN                South East  01JZ3NTBD7GFH6HMXCK172XS0F   
    1697      NaN  Yorkshire and the Humber  01JZ3NCH34Q66T8FMPAAQMK19N   
    1713      NaN  Yorkshire and the Humber  01JZ3NR12SF3Z3Z29X6X95S1VN   
    1738      NaN             West Midlands  01JZ3NCC7G4W5WBK9S46T36JXE   
    1852      NaN                North West  01JZ3NRAQ8V1TNRB59CM2DTE39   
    1905      NaN                    London  01JZ3NTKKZWA3CX7F820HPW61R   
    1937      NaN           East of England  01JZ3NRAJ34D00P9FFSRDJ39B3   
    1979      NaN                    London  01JZ3NCC845GPP7A73JFVT86E5   
    1997      NaN                South East  01JZ3NSYEVB9PQGDQ8258ZMY9C   
    2000      NaN             West Midlands  01JZ3NC9PRZKNNS40487M49PPW   
    2051      NaN           East of England  01JZ3NQZ57EW8Q1KS6H3JHX2GH   
    2139      NaN                   unknown  01JZ3NT1FA59SZQPFH19E0638A   
    2195      NaN             East Midlands  01JZ3NQZGM9X9PTNAMQTDNQDJ1   
    2322      NaN           East of England  01JZ3NC96W16Y6WKDF7DNYQECJ   
    2487      NaN                   unknown  01JZ3NCGGXXMBZZ5B2PFCX07JX   
    2511      NaN             West Midlands  01JZ3NRA1H5936ZQQV4P9N3YR3   
    2512      NaN                    London  01JZ3NC9T9Z1RSZP63NCCBJE40   
    2582      NaN                North East  01JZ3NR10VGV9S70GCJPYFQ2AJ   
    2589      NaN           East of England  01JZ3NR5T1YX89YBN62X0GG46Q   
    2615      NaN             West Midlands  01JZ3NR49PNQVTK6QH1A81RTN9   
    2648      NaN             East Midlands  01JZ3NC9ETTP8QPZ6WJZWSBZRF   
    2656      NaN                   unknown  01JZ3NT5DHWYJN8Z913RW3HPQE   
    2674      NaN                South West  01JZ3NR2HM9DE39M9WJSA1TM5B   
    2692      NaN                North West  01JZ3NSYT9K9SD186ESMJ7N0SX   
    2699      NaN                North East  01JZ3NR9W9WFTS7K6XCW8KW22H   
    2708      NaN                    London  01JZ3NR25BW6QBMZVSM58HZ7XS   
    2808      NaN                South East  01JZ3NCDJB231G033HHJRQNR2V   
    2927      NaN             West Midlands  01JZ3NTK84AZRGP5R1ZZ518QC7   
    2941      NaN             West Midlands  01JZ3NCFFCT0PQ3RXHXNVD01JC   
    3005      NaN             East Midlands  01JZ3NC54PM7TR91GSFXWQ57GP   
    3041      NaN           East of England  01JZ3NC7MJVERD3MQKGTZXXZ0M   
    3150      NaN                    London  01JZ3NC8AZ0NBWEC5M5JGFFV3B   
    3215      NaN                    London  01JZ3N57SACETTYDA5ER0M3SKC   
    3224      NaN  Yorkshire and the Humber  01JZ3N59N29JE02F5TRTSMKC5B   
    3250      NaN             East Midlands  01JZ3N579HDQH9ETN0PGA8MPTG   
    3294      NaN                South East  01JZ3N5989NSCYRYH9AT9BA983   
    3370      NaN                    London  01JZ3N57WBV5SKZ00A15F0VQ5C   
    3387      NaN  Yorkshire and the Humber  01JZ3N59XJWSKWM9ZYD0960M4C   
    3515      NaN           East of England  01JZ3N59MRW22XNQ7NY70KAA5F   
    3581      NaN             East Midlands  01JZ3N5ACTWKGCACT766K6A6CN   
    3591      NaN                   unknown  01JZ3NC5P0WG8FE82HBSRDWF2Q   
    3620      NaN                   unknown  01JZ3NC5FZ5MKZD6AG24PKW7TJ   
    3767      NaN                North East  01JZ3NC48S84QDQ0V0PGR0EK6Z   
    3915      NaN                South West  01JZ3N57ECQ3NEYTM11C6J0FJX   
    3968      NaN  Yorkshire and the Humber  01JZ3NC4371NHRTA89EAVEPK15   
    3976      NaN           East of England  01JZ3N5D0P8PEPMTS32KHR67R1   
    3985      NaN                South West  01JZ3N59NFRCS5VRRVQZ29KR41   
    4030      NaN           East of England  01JZ3NCDQEAS1RVHH11GQ9EAM8   
    4160      NaN                North West  01JZ3NCBH16AYDX471EDD6XW5W   
    4207      NaN                    London  01JZ3NTBG43WRAGV04SZS36HVM   
    4214      NaN                South West  01JZ3NT6DAD10JTS3Q38AZPJWA   
    4322      NaN                    London  01JZ3NCA5NX1M01H3JC96DPDZV   
    4332      NaN             East Midlands  01JZ3NCCMCHWQRWZM670FBSVHM   
    4405      NaN             West Midlands  01JZ3NTA4KZANMBYZ84VNQSBYX   
    4406      NaN                South West  01JZ3NC9VY45GT7XFG63G4ST85   
    4435      NaN                South West  01JZ3NT3Y6992R3PXBFP1WZ63W   
    4485      NaN             East Midlands  01JZ3NR19HV1681RN5K4K7BMDG   
    4516      NaN  Yorkshire and the Humber  01JZ3NSYPGE5N8VHXNKAD7X1TS   
    4524      NaN  Yorkshire and the Humber  01JZ3NTF5C617JTFPGHW671NRB   
    4674      NaN           East of England  01JZ3NTHWCVX3NBQPJ6RPJS88Q   
    4676      NaN                North West  01JZ3NSXRBWHP239BGXXKH07AJ   
    4710      NaN                South East  01JZ3NT56PV7E8E25VAQHV3M4D   
    4945      NaN           East of England  01JZ3NT9NQRB595YV5J5BHH731   
    4968      NaN                    London  01JZ3NCDJB231G033HHJRQNR2V   
    5011      NaN             West Midlands  01JZ3N56X4R6WZK47XA6FWC3F8   
    5067      NaN  Yorkshire and the Humber  01JZ3N552FMW6898G406DB65W2   
    5102      NaN           East of England  01JZ3N539A5HCSF7DWWR5NDZ0T   
    5134      NaN             East Midlands  01JZ3N50ZH8DS8K59WR84KWH88   
    5135      NaN             East Midlands  01JZ3N54TVQ5KQSQJ34MB6ERHH   
    5147      NaN             West Midlands  01JZ3N52A36FB3FKXD6BYY61T2   
    5153      NaN                    London  01JZ3N557MX027DQ49H078R06X   
    5400      NaN                South West  01JZ3N50YEH01KTS2W29ZWNT1A   
    5518      NaN  Yorkshire and the Humber  01JZ3N55JBVEK7FE9XF6TE8TJA   
    5555      NaN             West Midlands  01JZ3N55EPTAZNA3KX60RKB3NQ   
    5625      NaN                   unknown  01JZ3N51JR4MXWEX0PVEQEX3YQ   
    5644      NaN           East of England  01JZ3N5640TJCA54DKTD5R75NV   
    5743      NaN                North West  01JZ3N55QKV6GN1K1FGRJYKFY2   
    5771      NaN           East of England  01JZ3N55GZH53DW1GKNES14DCP   
    5820      NaN             East Midlands  01JZ3N56K2VDF9W3Z62NENPAP4   
    5835      NaN             West Midlands  01JZ3N54Z6BWRP2RE77PMR55DY   
    5904      NaN           East of England  01JZ3N56C1A9CHA0N1Y69ZAW81   
    5929      NaN             West Midlands  01JZ3N56BEC6J1R8ET7T160X8Z   
    5988      NaN             West Midlands  01JZ3N50YEH01KTS2W29ZWNT1A   
    6099      NaN                   unknown  01JZ3NCDKQYQ33RGR2CS64T41C   
    6148      NaN                    London  01JZ3NR1M67CYX605DCP871281   
    6157      NaN                   unknown  01JZ3NR4ASNJNCW588HWSCYWZ5   
    6217      NaN                North West  01JZ3NTFNRTV1V6EBA4GMC8JXT   
    6315      NaN             West Midlands  01JZ3NTPSNFHN58NPZX4M98N2R   
    6346      NaN             West Midlands  01JZ3NTDR5P43P7KC88HYK6B5S   
    6380      NaN                South West  01JZ3NTPEJEGD0WK256NKJTFW0   
    6403      NaN             East Midlands  01JZ3NC95QFKZKGKHZ6CQ5BVD1   
    6419      NaN             East Midlands  01JZ3NSW8ZT7AD3MSSXBVS136P   
    6438      NaN             West Midlands  01JZ3NCEW3PQZ56BG8RRZ1H49N   
    6439      NaN                North West  01JZ3NR921JVWNDYCKF47QPSZT   
    6539      NaN                South East  01JZ3NR24QFAQYPAJ4MH698QTM   
    6587      NaN                North East  01JZ3NTKNXP3HJD0X5H9B7VHVE   
    6614      NaN                    London  01JZ3NT1G7R5ZP4Z6QM65SZ81H   
    6639      NaN                    London  01JZ3NCBRMFKQ497PC6WYMQVJM   
    6790      NaN                North East  01JZ3NRACY05BGHRMSF0E80KA2   
    6799      NaN                    London  01JZ3NCA45T0SWY9X1ABERCAAT   
    6873      NaN             East Midlands  01JZ3NTE76G1VCKDBJ5XDF5FGS   
    6907      NaN                    London  01JZ3NCFN728GYS32BCWTT9XM8   
    6930      NaN                South West  01JZ3NTD8VBYESXYV0CAMF8X6F   
    6951      NaN                South East  01JZ3NTPSNFHN58NPZX4M98N2R   
    7038      NaN                South West  01JZ3NC42NMJYK1GNC236DHSQ7   
    7199      NaN             East Midlands  01JZ3NC68RR33ZRZBHH3E47EAP   
    7210      NaN           East of England  01JZ3NC93J9BJ2GD4GX4MR2NMK   
    7252      NaN             West Midlands  01JZ3NC8FJ5QJ9EZ1R1DZYGKW8   
    7256      NaN             West Midlands  01JZ3N5BVHDW7MCDH2WSS3MM54   
    7328      NaN                    London  01JZ3N5A9N6YP59W1W37YAG81Q   
    7378      NaN                North West  01JZ3N5C2EB7MTZZYJMR2ZK923   
    7383      NaN                   unknown  01JZ3N58AF9KYNNJ5H9FBMVD62   
    7385      NaN                North East  01JZ3NC4PZVK8FV1D9P3E7AMAC   
    7402      NaN           East of England  01JZ3N58E3A2BAV4NAV0E24KTM   
    7442      NaN                South West  01JZ3N5BWW7QMY5E7VDFH72XD6   
    7545      NaN                North East  01JZ3N5ABREGP3AYT376NBW4XR   
    7576      NaN                North East  01JZ3N58SYS0FX0XB3S7XVTB18   
    7623      NaN             West Midlands  01JZ3NC5RYVBZC2VFEXGHG7PNT   
    7635      NaN                South West  01JZ3N58FSR2HGBEDTB6AW9DDW   
    7668      NaN             East Midlands  01JZ3NC5SPYXCR4ZQPK8H1RGQJ   
    7687      NaN  Yorkshire and the Humber  01JZ3NC4JRAWG0XJTVWM56B8X7   
    7762      NaN             West Midlands  01JZ3N57BFXKC7V3CAK7PDQFYD   
    7775      NaN                   unknown  01JZ3NC4NK2EJ0Z7Z6154EV8AC   
    7795      NaN                South West  01JZ3NC8PVSQJW2J8B75RKHRSK   
    7850      NaN                North West  01JZ3N57YZDBW1KWS6SQSCFAEJ   
    7876      NaN                North West  01JZ3N5A225K3TPTA4YVM91MTT   
    7899      NaN  Yorkshire and the Humber  01JZ3NC509APNCN40Y3N0NRBQG   
    7916      NaN                    London  01JZ3NC45P3G4AZVF1YQD3EVCX   
    8035      NaN                North West  01JZ3NCA45T0SWY9X1ABERCAAT   
    8093      NaN                   unknown  01JZ3NR5EAH1EWEXG7QSKA4PXD   
    8094      NaN                    London  01JZ3NR70PXFAY6X8HY9ENFHBA   
    8106      NaN                South East  01JZ3NCDR0VC2V9K9NYGDWQTET   
    8137      NaN             West Midlands  01JZ3NR0KFE7HESXJMVF2BC45Q   
    8328      NaN             West Midlands  01JZ3NSWA8BWVV9TH7NECS08N9   
    8431      NaN                North West  01JZ3NSZJJX76405Q803YS9MPS   
    8499      NaN             East Midlands  01JZ3NR2CXW1T4SQJDRBHM6A8D   
    8507      NaN                North East  01JZ3NQZ8GH4JRR9TDNNNSAC98   
    8543      NaN                North East  01JZ3NR1XDTT9KZ7B0T1Z9FGV7   
    8583      NaN                North West  01JZ3NSYPGE5N8VHXNKAD7X1TS   
    8657      NaN                South East  01JZ3NR27M8AEFN8XG398R4M61   
    8675      NaN                North East  01JZ3NR478FFDYEZB04R48DMQM   
    8691      NaN             East Midlands  01JZ3NR4GWSBB8JK7S9CM60J6A   
    8715      NaN                   unknown  01JZ3NR2GA1PYYJYACA3HGP21P   
    8765      NaN           East of England  01JZ3NR9BREN1RGFHWEAH0J4HJ   
    8797      NaN             East Midlands  01JZ3NSZJJX76405Q803YS9MPS   
    8807      NaN             East Midlands  01JZ3NCAEJ3FWKYVC0PPTH48TC   
    8843      NaN                    London  01JZ3NT3Y6992R3PXBFP1WZ63W   
    8936      NaN                South East  01JZ3NCBAVPF9Z0N7N2VGXASTF   
    8941      NaN           East of England  01JZ3NTBJV0DHTMP743FW430FD   
    8978      NaN                    London  01JZ3NR5GRKBH10N3QE6V2Z03K   
    8988      NaN                South West  01JZ3NR3DNVF9E9SK32JNMT4MJ   
    9053      NaN                North West  01JZ3N5AAQSVJSM7RYQHNVKN53   
    9065      NaN                North East  01JZ3NC6S0JPQTV0MZRG2FS66J   
    9104      NaN             East Midlands  01JZ3NC8F7MB7CWNG3DRYQ32DY   
    9106      NaN             East Midlands  01JZ3N58WYG8CZC6V2Y870MYDF   
    9172      NaN                    London  01JZ3NC91KCPJXFH35KTB05X74   
    9200      NaN           East of England  01JZ3NC7CZBTEQ1FW0JG9Z18FF   
    9265      NaN             East Midlands  01JZ3NC3XC2CXCE1TCQ4EFH29K   
    9359      NaN                South East  01JZ3N59PW6KB4E65XAMAW1XPS   
    9424      NaN             East Midlands  01JZ3N59M4VVFW7YNABVMB5V0M   
    9486      NaN             West Midlands  01JZ3N5A946V9P8GFVQE6ER6CR   
    9534      NaN             West Midlands  01JZ3NC4RXH4JZKKT4W3FMSH0G   
    9574      NaN                   unknown  01JZ3NC8VRE9VZ1HYC2RRS67PQ   
    9643      NaN                North West  01JZ3NC882KTY2P6XF33WN6QE1   
    9644      NaN  Yorkshire and the Humber  01JZ3N5AAZ497MTK2995E81P8T   
    9653      NaN                North East  01JZ3N58SYS0FX0XB3S7XVTB18   
    9697      NaN                    London  01JZ3N5AEZMBAXSWZTXTRS06KT   
    9723      NaN                    London  01JZ3N58YR195RJ7CND75PB02Y   
    9726      NaN             West Midlands  01JZ3NC8NWGSJ32AC1JDJVHX6X   
    9747      NaN                South East  01JZ3N58CFG3G4ZJ8P3012GXBT   
    9766      NaN                North West  01JZ3NC7PR23SZXEAKV152FVH3   
    9830      NaN             East Midlands  01JZ3N5CXAWWXN60W8D2TTGXA2   
    9843      NaN                South West  01JZ3NC8KG6BJE7TJ66MY5ATSX   
    9870      NaN             West Midlands  01JZ3N573PQV7J0Y4RE0CRZE1C   
    9902      NaN                   unknown  01JZ3N574ETCVZ4S3P9YTX4WXZ   
    9936      NaN                   unknown  01JZ3NC8T38JJHZPKKRQXM1DG3   
    10045     NaN             West Midlands  01JZ3N59X6BNFNH0V3CACE5054   
    10061     NaN                North West  01JZ3NC51CDFHE4B1FC18XE56C   
    10181     NaN             East Midlands  01JZ3NC42NMJYK1GNC236DHSQ7   
    10206     NaN  Yorkshire and the Humber  01JZ3N5821R8KZDA4M2VB9J0CM   
    10254     NaN  Yorkshire and the Humber  01JZ3N5BWA1BCBV92DVHTJCETT   
    10373     NaN                    London  01JZ3NC882KTY2P6XF33WN6QE1   
    10406     NaN                    London  01JZ3N5D0P8PEPMTS32KHR67R1   
    10508     NaN                   unknown  01JZ3NC5JPGCSKHFQBQ6XA0JY9   
    10527     NaN                   unknown  01JZ3N5A69R87PE0PYKN5PP71P   
    10607     NaN                North East  01JZ3N57TQ7SAV1WKF9VAKTVEV   
    10635     NaN                    London  01JZ3N5C14HAYMC1QR0V4F5QDN   
    10643     NaN  Yorkshire and the Humber  01JZ3N5ABREGP3AYT376NBW4XR   
    10663     NaN                North East  01JZ3N58K0B5VT7DVZKTKXK1FA   
    10706     NaN                South East  01JZ3N5BWW7QMY5E7VDFH72XD6   
    10723     NaN  Yorkshire and the Humber  01JZ3NC80K9RMN8ZRZ347S5GMD   
    10727     NaN                South West  01JZ3NC79BVY88G9AN47EJ1BZ0   
    10733     NaN                    London  01JZ3N5A9N6YP59W1W37YAG81Q   
    10753     NaN                North East  01JZ3NC8G3EJZNQH965WV8JKAF   
    10843     NaN             West Midlands  01JZ3NC5Z68Y8E4PVRX0R0NX50   
    10851     NaN                North East  01JZ3N5ABGS0A456R3MD9KS46E   
    10905     NaN  Yorkshire and the Humber  01JZ3N57CKA9BR1N58XXCAFEW9   
    10935     NaN             West Midlands  01JZ3NC8PVSQJW2J8B75RKHRSK   
    
                                          Product Name                  Category  \
    12                               Lemon Herb Quinoa             Food - Grains   
    79                Sports Water Bottle with Infuser                   Fitness   
    238                                Peach Green Tea          Food - Beverages   
    266                            Beef Stroganoff Mix          Food - Meal Kits   
    341                              Bamboo Toothbrush                    Health   
    364                     Oven-Baked Chicken Tenders               Food - Meat   
    464                       Adjustable Standing Desk                    Office   
    558                          Electric Food Steamer                   Kitchen   
    637                      Chocolate Fudge Ice Cream    Food - Frozen Desserts   
    729             Pet Water Fountain with Filtration                      Pets   
    799                             Fishing Tackle Box                   Outdoor   
    912                                  Wall Calendar                      Home   
    916                            Gardening Tool Belt                    Garden   
    998                                   Tomato Paste       Food - Canned Goods   
    1003                                    White Rice             Food - Grains   
    1198                            Travel Laundry Bag                    Travel   
    1295             Peanut Butter Banana Smoothie Mix          Food - Beverages   
    1333                      Peach Mango Smoothie Mix          Food - Beverages   
    1355                        Portable Hammock Swing                   Outdoor   
    1449                            Sun-Dried Tomatoes         Food - Vegetables   
    1538              Rechargeable Electric Toothbrush                    Health   
    1614                     Striped Long Sleeve Shirt         Clothing - Shirts   
    1671                      Tandoori Chicken Skewers               Food - Meat   
    1697                          Folding Pocket Knife                     Tools   
    1713                             Maple Bacon Jerky               Food - Meat   
    1738                                  Lemonade Mix          Food - Beverages   
    1852                                  Coffee Maker                   Kitchen   
    1905               Strawberry Banana Smoothie Pack             Food - Frozen   
    1937                       Outdoor Camping Hammock                   Outdoor   
    1979                        Vegetable Stir Fry Mix      Food - Fresh Produce   
    1997                         Butternut Squash Soup              Food - Soups   
    2000                           Veggie Lovers Pizza       Food - Frozen Foods   
    2051                          Plant Pot Drip Trays                    Garden   
    2139                       Basil-infused Olive Oil        Food - Cooking Oil   
    2195                               Puzzle Game Set                      Toys   
    2322                   Mediterranean Chickpea Bowl     Food - Prepared Foods   
    2487                   Pet Travel Backpack Carrier                      Pets   
    2511                 Smartphone Tripod with Remote               Photography   
    2512                          Honey Sesame Chicken        Food - Frozen Food   
    2582               Buffalo Style Cauliflower Bites  Food - Frozen Vegetables   
    2589                       Microwave Popcorn Maker                   Kitchen   
    2615                                Linen Trousers        Clothing - Bottoms   
    2648                                       Lentils             Food - Grains   
    2656   Smartphone Car Mount with Wireless Charging                Automotive   
    2674                                 Cork Yoga Mat                   Fitness   
    2692                                       Cabbage            Food - Produce   
    2699                                   Coconut Oil    Food - Oils & Vinegars   
    2708                         Eco-Friendly Yoga Mat                   Fitness   
    2808                 Multicolored LED Strip Lights                      Home   
    2927                        Compact Digital Camera               Photography   
    2941                          Natural Fruit Snacks             Food - Snacks   
    3005                      Handmade Leather Journal                     Books   
    3041                        Teriyaki Tofu Stir-Fry     Food - Prepared Meals   
    3150                   Customizable Photo Calendar                     Books   
    3215                         Vegetable Quinoa Bowl       Food - Frozen Meals   
    3224                            Fresh Strawberries            Food - Produce   
    3250                       Adjustable Kneeling Pad                    Garden   
    3294                  Fitness Resistance Bands Set                   Fitness   
    3370                 Portable Bluetooth Headphones                     Audio   
    3387                    Outdoor Adventure Backpack                   Outdoor   
    3515                          Basic V-Neck T-Shirt           Clothing - Tops   
    3581                           Smart LED Desk Lamp                    Office   
    3591                            Pet Water Fountain                      Pets   
    3620                                Beef Stew Meat               Food - Meat   
    3767                         Infrared Space Heater           Home Appliances   
    3915                            Baked Potato Chips             Food - Snacks   
    3968                Dual Function Electric Skillet                   Kitchen   
    3976                         Wireless Charging Pad               Accessories   
    3985                  Chocolate Mint Protein Shake          Food - Beverages   
    4030                            Banana Nut Muffins             Food - Bakery   
    4160       Fitness Tracker with Heart Rate Monitor                   Fitness   
    4207                      Fitness Activity Journal                   Fitness   
    4214                     Mixed Berry Smoothie Pack        Food - Frozen Food   
    4322                           Fitness Foam Roller                   Fitness   
    4332                              Luxury Bath Robe                  Clothing   
    4405                             Andouille Sausage               Food - Meat   
    4406                               Spaghetti Sauce       Food - Canned Goods   
    4435                              Electric Hot Pot                   Kitchen   
    4485                         Italian Sausage Links     Food - Meat & Poultry   
    4516                             Coffee Making Kit                   Kitchen   
    4524                             Vegetable Samosas             Food - Frozen   
    4674                      Digital Meat Thermometer                   Kitchen   
    4676                              Wireless Earbuds                     Audio   
    4710                   Portable Hammock with Stand                   Outdoor   
    4945                 Men's Waterproof Hiking Boots                  Footwear   
    4968                 Multicolored LED Strip Lights                      Home   
    5011                       Non-Stick Baking Sheets                   Kitchen   
    5067                           Organic Coconut Oil               Food - Oils   
    5102                        Car Diagnostic Scanner                Automotive   
    5134                           Poppy Seed Dressing         Food - Condiments   
    5135                          Deluxe First Aid Kit                    Health   
    5147                            Magnetic Chess Set                      Toys   
    5153                            Car Seat Organizer                Automotive   
    5400                            Printed Maxi Skirt         Clothing - Skirts   
    5518                           Zesty Garlic Hummus             Food - Snacks   
    5555                                 Wrap Jumpsuit      Clothing - Jumpsuits   
    5625                      Chocolate Protein Powder        Food - Supplements   
    5644                             Tactical Backpack                   Outdoor   
    5743                               Floral Wrap Top           Clothing - Tops   
    5771                      Carrot and Celery Sticks            Food - Produce   
    5820                        Kids' Art Supplies Kit                      Toys   
    5835                       Caribbean Jerk Marinade          Food - Marinades   
    5904                        Nutty Granola Clusters             Food - Cereal   
    5929          Cocktail Shaker and Mixing Glass Set                   Kitchen   
    5988                            Printed Maxi Skirt         Clothing - Skirts   
    6099                              Sous Vide Cooker                   Kitchen   
    6148                                 Electric Bike                  Bicycles   
    6157                         Avocado Lime Dressing         Food - Condiments   
    6217                          Baked Mac and Cheese       Food - Frozen Foods   
    6315                            Pet Safety Harness                      Pets   
    6346                                Tailgating Set                   Outdoor   
    6380                       LED Flashing Pet Collar                      Pets   
    6403                     Pepper Jack Cheese Sticks             Food - Snacks   
    6419                                  USB Desk Fan                      Home   
    6438                              Vegetarian Pizza       Food - Frozen Foods   
    6439                           Buttermilk Pancakes          Food - Breakfast   
    6539                              Toy Building Set                      Toys   
    6587                     Asian Stir-Fry Vegetables       Food - Frozen Foods   
    6614                        Potato Wedge Seasoning         Food - Condiments   
    6639                              Spicy Tuna Rolls            Food - Seafood   
    6790                                       Pet Bed                      Pets   
    6799                Pineapple Teriyaki Chicken Mix               Food - Meat   
    6873                         Bluetooth Car Adapter                Automotive   
    6907                        Stainless Steel Straws                   Kitchen   
    6930                       Wall-Mounted Spice Rack                   Kitchen   
    6951                            Pet Safety Harness                      Pets   
    7038                      Portable Air Conditioner                       NaN   
    7199                      Handheld Garment Steamer                      Home   
    7210                            Luxe Velvet Blazer      Clothing - Outerwear   
    7252                          Spicy Garlic Edamame             Food - Snacks   
    7256                 Peanut Butter Banana Smoothie          Food - Beverages   
    7328                      Rechargeable Hand Warmer               Accessories   
    7378                               Sunflower Seeds                       NaN   
    7383                            Board Game Storage                      Toys   
    7385                        Herb Seasoned Couscous             Food - Grains   
    7402                       Adjustable Laptop Stand                    Office   
    7442                                  Multi-Cooker                       NaN   
    7545                           Sweet Corn Fritters             Food - Frozen   
    7576                       Green Tea Matcha Powder          Food - Beverages   
    7623                                    Cacao Nibs             Food - Baking   
    7635                                  Almond Flour             Food - Baking   
    7668                           Ginger Turmeric Tea          Food - Beverages   
    7687                                  Lentil Pasta              Food - Pasta   
    7762                       Frozen Cauliflower Rice       Food - Frozen Foods   
    7775                    Electric Toothbrush Holder                    Health   
    7795                       Frozen Mixed Vegetables             Food - Frozen   
    7850                  Garlic and Herb Cream Cheese              Food - Dairy   
    7876                            Hand Crank Blender                   Kitchen   
    7899                   Adjustable Resistance Bands                   Fitness   
    7916                        Lemon Pepper Seasoning         Food - Seasonings   
    8035                Pineapple Teriyaki Chicken Mix               Food - Meat   
    8093                         Vegan Caesar Dressing         Food - Condiments   
    8094                           Cocktail Shaker Set                   Kitchen   
    8106                     Portable Dog Water Bottle                      Pets   
    8137                  Lightweight Backpacking Tent                   Outdoor   
    8328                           Smoked Gouda Cheese              Food - Dairy   
    8431                        Knitted Infinity Scarf    Clothing - Accessories   
    8499                              Black Bean Salsa             Food - Snacks   
    8507                                   Slim Wallet               Accessories   
    8543                        Bamboo Cotton Tank Top           Clothing - Tops   
    8583                             Coffee Making Kit                   Kitchen   
    8657                          Chocolate Mint Thins             Food - Snacks   
    8675                           Honey Garlic Shrimp            Food - Seafood   
    8691                  Biodegradable Dog Waste Bags                       NaN   
    8715                         Mechanical Pencil Set                    Office   
    8765                          Silicone Baking Cups                   Kitchen   
    8797                        Knitted Infinity Scarf    Clothing - Accessories   
    8807                                     Hot Salsa               Food - Dips   
    8843                              Electric Hot Pot                   Kitchen   
    8936                           Savory Oatmeal Cups          Food - Breakfast   
    8941                         Classic White T-Shirt           Clothing - Tops   
    8978                 Pasta Portion Control Measure                   Kitchen   
    8988                        Portable Phone Charger               Accessories   
    9053                           Dark Chocolate Tart           Food - Desserts   
    9065                                Sesame Noodles        Food - Grab-and-Go   
    9104                           Travel Jewelry Case               Accessories   
    9106                         Almond Butter Cookies             Food - Snacks   
    9172                           Garlic Butter Sauce         Food - Condiments   
    9200                      Compressed Towel Tablets                    Travel   
    9265                                 Laptop Sleeve               Accessories   
    9359                        Organic Coconut Yogurt              Food - Dairy   
    9424                           Mini Food Processor                   Kitchen   
    9486                             Pet First Aid Kit                      Pets   
    9534                           Non-Stick Grill Pan                   Kitchen   
    9574                     Organic Black Bean Burger       Food - Frozen Foods   
    9643                            Portable Ice Maker                   Kitchen   
    9644                  Mediterranean Couscous Salad             Food - Salads   
    9653                       Green Tea Matcha Powder          Food - Beverages   
    9697                        Casual Cropped Sweater       Clothing - Sweaters   
    9723                                   Pasta Maker                   Kitchen   
    9726                        Essential Oil Diffuser                    Health   
    9747                         Spinach Artichoke Dip             Food - Snacks   
    9766                                 Buffalo Sauce         Food - Condiments   
    9830                                   Brown Sugar             Food - Baking   
    9843                         Nordic Berry Smoothie       Food - Frozen Foods   
    9870                                  Banana Chips             Food - Snacks   
    9902                               Vegetable Curry       Food - Frozen Foods   
    9936                Set of Decorative Storage Bins                      Home   
    10045                     Teriyaki Chicken Skewers               Food - Meat   
    10061                         Dog Training Whistle                      Pets   
    10181                     Portable Air Conditioner                       NaN   
    10206                     Garam Masala Spice Blend             Food - Spices   
    10254                  Rustic Wooden Picture Frame                      Home   
    10373                           Portable Ice Maker                   Kitchen   
    10406                        Wireless Charging Pad               Accessories   
    10508                           Trail Mix (Deluxe)             Food - Snacks   
    10527                           Herbed Goat Cheese             Food - Cheese   
    10607                Children's Educational Puzzle                      Toys   
    10635           Fitness Jump Rope with LCD Counter                   Fitness   
    10643                          Sweet Corn Fritters             Food - Frozen   
    10663                          Snack Container Set                   Kitchen   
    10706                                 Multi-Cooker                       NaN   
    10723                            Organic Green Tea          Food - Beverages   
    10727                          Garlic and Herb Rub             Food - Spices   
    10733                     Rechargeable Hand Warmer               Accessories   
    10753                              Vegetable Korma             Food - Frozen   
    10843                          Baked Falafel Balls  Food - Frozen Vegetables   
    10851                 Mediterranean Chickpea Salad             Food - Salads   
    10905                           Crispy Potato Tots       Food - Frozen Foods   
    10935                      Frozen Mixed Vegetables             Food - Frozen   
    
                                 Sub-Category   Sales  Cost Price  Quantity  \
    12                        Flavored Quinoa    3.49       1.047        13   
    79                         Hydration Gear   19.99       5.997        19   
    238                                   Tea    3.49       1.047        19   
    266                    Pasta & Rice Mixes    5.49       1.647         5   
    341                   Oral Care & Hygiene    5.99       1.797        15   
    364                               Poultry    6.99       2.097        13   
    464                             Furniture  299.99      89.997        13   
    558                      Small Appliances   59.99      17.997         3   
    637                             Ice Cream    5.99       1.797         7   
    729                          Pet Supplies   39.99      11.997        10   
    799                     Fishing Equipment   24.99       7.497         8   
    912     Decorative Wall Art & Accessories   17.99       5.397        17   
    916                 Gardening Accessories   22.99       6.897        16   
    998                   Sauces & Condiments    1.29       0.387        11   
    1003                                 Rice    1.49       0.596        19   
    1198                   Travel Accessories    9.99       3.996        19   
    1295                            Smoothies    4.49       1.796         8   
    1333                            Smoothies    5.99       2.396        19   
    1355                    Outdoor Furniture   59.99      17.997        18   
    1449                           Vegetables    3.99       1.596         9   
    1538                  Oral Care & Hygiene   49.99      14.997         4   
    1614                        Casual Shirts   29.99      11.996         9   
    1671                      Marinated Meats    7.99       3.196         2   
    1697                           Hand Tools   24.99       7.497         2   
    1713                                Jerky    6.99       2.796        16   
    1738                          Drink Mixes    1.99       0.597         1   
    1852                  Beverage Appliances   89.99      35.996        12   
    1905                        Frozen Snacks    4.99       1.996        17   
    1937                    Camping Equipment   29.99      11.996        14   
    1979                      Vegetable Mixes    3.29       0.987        14   
    1997                     Vegetarian Soups    3.49       1.396        17   
    2000                         Frozen Pizza   10.41       3.697        18   
    2051                Gardening Accessories   11.41       4.996         5   
    2139                         Infused Oils    8.41       3.796         7   
    2195                          Board Games   36.41      14.996        17   
    2322                    Plant-Based Meals    7.91       2.947         4   
    2487                   Travel Accessories   51.41      15.997         3   
    2511                Tripods & Accessories   31.41      12.996        17   
    2512                         Frozen Meals   10.41       3.697         7   
    2582                 Frozen Veggie Snacks    6.91       3.196         3   
    2589                     Small Appliances   21.41       8.996         3   
    2615                             Trousers   46.41      18.996         4   
    2648                              Legumes    4.41       1.897         8   
    2656                    Phone Accessories   41.41      16.996        13   
    2674                       Yoga Equipment   41.41      16.996         2   
    2692                           Vegetables    2.71       1.516         8   
    2699                                 Oils    7.91       3.596         2   
    2708        Sustainable Fitness Equipment   41.41      16.996        17   
    2808                     Lighting & Lamps   31.41       9.997        17   
    2927                      Digital Cameras  251.41     100.996        14   
    2941                       Healthy Snacks    5.41       2.197        18   
    3005                             Journals   39.99      11.997        14   
    3041                     Vegetarian Meals    7.49       2.247         9   
    3150                            Calendars   19.99       5.997        18   
    3215                   Frozen Grain Bowls    5.99       1.797        15   
    3224                               Fruits    3.99       1.197        12   
    3250                Gardening Accessories   18.99       5.697        17   
    3294          Strength Training Equipment   34.99      10.497        14   
    3370           Wireless Audio Accessories   79.99      23.997        11   
    3387                    Camping Equipment   59.99      17.997        17   
    3515                             T-Shirts   19.99       5.997         2   
    3581                             Lighting   39.99      11.997        13   
    3591                         Pet Supplies   39.99      11.997         4   
    3620                             Red Meat    5.99       1.797        10   
    3767                   Heating Appliances   99.99      29.997        11   
    3915                       Healthy Snacks    2.49       0.747        15   
    3968                             Cookware   59.99      17.997         4   
    3976                   Mobile Accessories   19.99       5.997        10   
    3985                        Health Drinks    3.99       1.197        17   
    4030                              Muffins    5.49       1.347        20   
    4160                  Wearable Technology   60.99      17.997         2   
    4207              Health & Wellness Tools   15.99       5.996         7   
    4214                        Frozen Fruits    6.99       2.396         8   
    4322                       Recovery Tools   30.99       8.997        12   
    4332                           Loungewear   50.99      14.997         4   
    4405                      Processed Meats    6.49       2.196         7   
    4406                  Sauces & Condiments    3.99       0.897        12   
    4435                             Cookware   50.99      19.996         6   
    4485                        Meat Products    6.99       2.396        10   
    4516                   Coffee Accessories   45.99      17.996         6   
    4524                        Frozen Snacks    5.99       1.996         5   
    4674             Cooking Tools & Utensils   25.99       9.996        14   
    4676                              Earbuds   70.99      27.996         1   
    4710                    Camping Equipment   70.99      27.996        18   
    4945                     Outdoor Footwear   90.99      35.996        16   
    4968                     Lighting & Lamps   30.99       8.997         6   
    5011                   Baking Accessories   28.99       8.447         8   
    5067                                 Oils    7.99       2.147         1   
    5102                     Automotive Tools   48.99      14.447         1   
    5134                             Dressing    2.49       0.497         7   
    5135   Emergency Preparedness & First Aid   38.99      11.447         9   
    5147                          Board Games   18.99       5.447        10   
    5153             Car Interior Accessories   13.99       3.947        15   
    5400                               Skirts   38.99      11.447        11   
    5518                     Dips and Spreads    2.99       0.647        16   
    5555                            Jumpsuits   53.99      15.947         6   
    5625                          Supplements   23.99       6.947        17   
    5644                    Camping Equipment   58.99      17.447         8   
    5743                         Women's Tops   48.99      14.447        19   
    5771                     Fresh Vegetables    1.99       0.347        12   
    5820               Creative Arts & Crafts   28.99       8.447        13   
    5835                            Marinades    2.79       0.587        12   
    5904                              Granola    1.49       0.197         7   
    5929                              Barware   38.99      11.447        11   
    5988                               Skirts   38.99      11.447        16   
    6099                   Cooking Appliances   79.14      23.497        19   
    6148                             Bicycles  899.14     359.496        11   
    6157                             Dressing    3.44       1.216        13   
    6217                         Frozen Meals    5.14       1.896         2   
    6315                      Pet Safety Gear   24.14       9.496         1   
    6346                   Outdoor Recreation   89.14      35.496         5   
    6380                      Pet Accessories   14.14       5.496        10   
    6403                        Savory Snacks    1.64       0.247         6   
    6419                      Home Appliances   14.14       5.496         4   
    6438              Frozen Vegetarian Meals    4.64       1.147        16   
    6439                   Pancakes & Waffles    3.14       1.096        14   
    6539                        Building Toys   29.14      11.496         1   
    6587                    Frozen Vegetables    2.14       0.696        15   
    6614                     Seasoning Blends    1.64       0.496         2   
    6639                                Sushi    5.64       1.447         1   
    6790                      Pet Accessories   39.14      15.496         4   
    6799                 Marinades and Sauces    6.14       1.597         4   
    6873               Automotive Accessories   24.14       9.496         6   
    6907                  Kitchen Accessories   12.14       3.397        19   
    6930       Kitchen Storage & Organization   39.14      15.496         6   
    6951                      Pet Safety Gear   24.14       9.496        13   
    7038                   Cooling Appliances  299.14      89.497         1   
    7199                      Home Appliances   34.14       9.997        12   
    7210                              Jackets   89.14      26.497        19   
    7252                        Savory Snacks    3.14       0.697         9   
    7256                            smoothies    3.14       0.697        18   
    7328                        Personal Care   22.14       6.397        18   
    7378                         Seeds & Nuts    2.14       0.397         9   
    7383                     Game Accessories   19.14       5.497         1   
    7385                    Flavored Couscous    1.64       0.247         2   
    7402                   Laptop Accessories   29.14       8.497        13   
    7442                   Cooking Appliances   89.14      26.497        15   
    7545                    Frozen Appetizers    3.64       0.847        16   
    7576                                  Tea   15.14       4.297        13   
    7623                   Baking Ingredients    5.64       1.447         8   
    7635                       Flours & Meals    5.14       1.297         7   
    7668                           Herbal Tea    2.64       0.547         4   
    7687                      Specialty Pasta    4.14       0.997         9   
    7762                    Frozen Vegetables    2.14       0.397         7   
    7775                  Oral Care & Hygiene   14.14       3.997        19   
    7795                    Frozen Vegetables    1.14       0.097        10   
    7850                       Cheese Spreads    2.64       0.547         3   
    7876                     Small Appliances   18.14       5.197         5   
    7899          Strength Training Equipment   39.14      11.497         2   
    7916                    Citrus Seasonings    2.44       0.487         6   
    8035                 Marinades and Sauces    6.24       1.847         7   
    8093                             Dressing    3.24       1.346        11   
    8094                              Barware   29.24      11.746        14   
    8106                      Dog Accessories   18.24       5.447         8   
    8137                    Camping Equipment  129.24      51.746         3   
    8328                               Cheese    4.74       1.946        19   
    8431                              Scarves   29.24      11.746         5   
    8499                      Salsas and Dips    2.74       1.146        15   
    8507                              Wallets   24.24       9.746         6   
    8543                  Sustainable Fashion   22.24       8.946        12   
    8583                   Coffee Accessories   44.24      17.746         9   
    8657                                Candy    2.24       0.946        16   
    8675                     Prepared Seafood    7.74       3.146         4   
    8691                         Dog Supplies   14.24       5.746        12   
    8715                  Writing Instruments   19.24       7.746        12   
    8765                   Baking Accessories   10.24       4.146        10   
    8797                              Scarves   29.24      11.746        19   
    8807                           Salsa/Dips    1.54       0.437        20   
    8843                             Cookware   49.24      19.746         5   
    8936             Savory Breakfast Options    1.24       0.347        17   
    8941                             T-Shirts   19.24       7.746         1   
    8978             Cooking Tools & Utensils    9.24       3.746        18   
    8988                   Mobile Accessories   29.24      11.746        20   
    9053                   Chocolate Desserts    6.29       1.887        20   
    9065                              Noodles    5.99       1.797        17   
    9104                      Jewelry Storage   24.99       7.497         7   
    9106                     Nut-Based Snacks    4.49       1.347        12   
    9172                               Sauces    3.59       1.077        14   
    9200                   Travel Accessories   12.99       3.897         8   
    9265                   Laptop Accessories   24.99       7.497         9   
    9359                   Dairy Alternatives    4.49       1.347        16   
    9424               Food Preparation Tools   39.99      11.997         4   
    9486                  Pet Health and Care   29.99       8.997         2   
    9534                             Cookware   39.99      11.997        16   
    9574                   Frozen Vegan Meals    4.49       1.347        10   
    9643                     Small Appliances  199.99      59.997        20   
    9644                         Grain Salads    5.49       1.647         9   
    9653                                  Tea   15.99       4.797         1   
    9697                             Sweaters   39.99      11.997        15   
    9723                     Small Appliances   39.00      11.700        14   
    9726              Aromatherapy & Wellness   34.99      10.497         1   
    9747                     Dips and Spreads    4.99       1.497        16   
    9766                         Spicy Sauces    2.99       0.897        14   
    9830                           Sweeteners    1.79       0.537         9   
    9843               Frozen Fruit Smoothies    3.99       1.197        14   
    9870                         Sweet Snacks    1.99       0.597        11   
    9902                    Frozen Vegetables    5.99       1.797        20   
    9936                    Home Organization   34.99      10.497        18   
    10045                     Marinated Meats    8.99       2.697        12   
    10061                   Training Supplies    8.99       2.697         4   
    10181                  Cooling Appliances  299.99      89.997        16   
    10206           Regional Seasoning Blends    2.79       0.837         2   
    10254   Decorative Wall Art & Accessories   19.99       5.997        10   
    10373                    Small Appliances  199.99      59.997        10   
    10406                  Mobile Accessories   19.99       5.997        11   
    10508                  Nuts and Trail Mix    4.59       1.377        11   
    10527                   Specialty Cheeses    5.49       1.647        10   
    10607                    Educational Toys   19.99       5.997        10   
    10635                    Cardio Equipment   15.99       4.797        12   
    10643                   Frozen Appetizers    4.49       1.347        11   
    10663         Food Storage & Organization   19.99       5.997         4   
    10706                  Cooking Appliances   89.99      26.997        11   
    10723                          Herbal Tea    4.29       1.287        18   
    10727                         Herb Blends    2.29       0.687         3   
    10733                       Personal Care   22.99       6.897        11   
    10753                        Frozen Meals    6.49       1.947         7   
    10843                Frozen Veggie Snacks    5.99       1.797         8   
    10851                      Healthy Salads    5.99       1.797        16   
    10905                       Frozen Snacks    3.69       1.107        15   
    10935                   Frozen Vegetables    1.99       0.597        14   
    
           Discount  
    12         0.11  
    79         0.34  
    238        0.04  
    266        0.00  
    341        0.04  
    364        0.26  
    464        0.28  
    558        0.01  
    637        0.09  
    729        0.11  
    799        0.00  
    912        0.00  
    916        0.34  
    998        0.26  
    1003       0.24  
    1198       0.00  
    1295       0.23  
    1333       0.35  
    1355       0.33  
    1449       0.25  
    1538       0.00  
    1614       0.35  
    1671       0.36  
    1697       0.32  
    1713       0.00  
    1738       0.35  
    1852       0.30  
    1905       0.35  
    1937       0.24  
    1979       0.00  
    1997       0.01  
    2000       0.14  
    2051       0.14  
    2139       0.09  
    2195       0.01  
    2322       0.19  
    2487       0.07  
    2511       0.00  
    2512       0.16  
    2582       0.07  
    2589       0.15  
    2615       0.16  
    2648       0.00  
    2656       0.04  
    2674       0.17  
    2692       0.02  
    2699       0.09  
    2708       0.08  
    2808       0.17  
    2927       0.15  
    2941       0.12  
    3005       0.32  
    3041       0.33  
    3150       0.28  
    3215       0.28  
    3224       0.38  
    3250       0.36  
    3294       0.18  
    3370       0.27  
    3387       0.00  
    3515       0.08  
    3581       0.14  
    3591       0.30  
    3620       0.35  
    3767       0.05  
    3915       0.23  
    3968       0.03  
    3976       0.32  
    3985       0.00  
    4030       0.10  
    4160       0.00  
    4207       0.15  
    4214       0.09  
    4322       0.15  
    4332       0.10  
    4405       0.16  
    4406       0.00  
    4435       0.14  
    4485       0.00  
    4516       0.12  
    4524       0.00  
    4674       0.11  
    4676       0.17  
    4710       0.07  
    4945       0.13  
    4968       0.10  
    5011       0.28  
    5067       0.33  
    5102       0.00  
    5134       0.08  
    5135       0.07  
    5147       0.04  
    5153       0.20  
    5400       0.19  
    5518       0.39  
    5555       0.20  
    5625       0.40  
    5644       0.04  
    5743       0.08  
    5771       0.36  
    5820       0.11  
    5835       0.22  
    5904       0.23  
    5929       0.07  
    5988       0.32  
    6099       0.01  
    6148       0.22  
    6157       0.07  
    6217       0.29  
    6315       0.32  
    6346       0.23  
    6380       0.16  
    6403       0.24  
    6419       0.26  
    6438       0.00  
    6439       0.28  
    6539       0.28  
    6587       0.15  
    6614       0.40  
    6639       0.08  
    6790       0.17  
    6799       0.26  
    6873       0.39  
    6907       0.24  
    6930       0.10  
    6951       0.40  
    7038       0.00  
    7199       0.24  
    7210       0.18  
    7252       0.00  
    7256       0.39  
    7328       0.11  
    7378       0.17  
    7383       0.00  
    7385       0.00  
    7402       0.30  
    7442       0.35  
    7545       0.04  
    7576       0.12  
    7623       0.21  
    7635       0.00  
    7668       0.03  
    7687       0.22  
    7762       0.19  
    7775       0.18  
    7795       0.39  
    7850       0.00  
    7876       0.00  
    7899       0.00  
    7916       0.15  
    8035       0.06  
    8093       0.00  
    8094       0.04  
    8106       0.05  
    8137       0.01  
    8328       0.01  
    8431       0.03  
    8499       0.01  
    8507       0.07  
    8543       0.09  
    8583       0.06  
    8657       0.04  
    8675       0.06  
    8691       0.00  
    8715       0.00  
    8765       0.06  
    8797       0.05  
    8807       0.06  
    8843       0.02  
    8936       0.01  
    8941       0.06  
    8978       0.01  
    8988       0.01  
    9053       0.12  
    9065       0.00  
    9104       0.00  
    9106       0.27  
    9172       0.04  
    9200       0.07  
    9265       0.28  
    9359       0.15  
    9424       0.12  
    9486       0.16  
    9534       0.14  
    9574       0.00  
    9643       0.22  
    9644       0.06  
    9653       0.34  
    9697       0.18  
    9723       0.06  
    9726       0.15  
    9747       0.32  
    9766       0.34  
    9830       0.24  
    9843       0.25  
    9870       0.04  
    9902       0.40  
    9936       0.03  
    10045      0.11  
    10061      0.18  
    10181      0.19  
    10206      0.36  
    10254      0.00  
    10373      0.37  
    10406      0.21  
    10508      0.00  
    10527      0.07  
    10607      0.40  
    10635      0.30  
    10643      0.34  
    10663      0.24  
    10706      0.01  
    10723      0.29  
    10727      0.18  
    10733      0.32  
    10753      0.07  
    10843      0.23  
    10851      0.23  
    10905      0.00  
    10935      0.23  
    


```python
#there are 220 county names are missing so I am going to impute Mode because from regions and postcode I have seen that all the missing values are from england
df['Country']=df['Country'].fillna('England')
#print(df['Country'])
```


```python
#Here I gonna see that is there any link between categories and subcategories missng values. I found that every missing categoy has different subcategories.

import pandas as pd

# Show all columns and rows
pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)

# Filter the rows
missing_category_with_subcategory = df[df['Category'].isna() & df['Sub-Category'].notna()]

# Display all columns for those rows
print(missing_category_with_subcategory)


```

             Order ID Order Date Order Mode Customer ID        City Postal Code  \
    41     URP-701003 2024-01-02   In-Store    MC022478   Liverpool         L33   
    152    OGD-569829 2024-04-29     Online    LW071445      Pentre         SY4   
    187    PNA-042598 2024-11-27   In-Store    EY021607     Preston         PR1   
    192    OMI-935342 2024-09-09     Online    CX029462       Upton         WF9   
    248    GBM-233345 2024-01-20     Online    AU020860  Church End          N3   
    334    EWK-880117 2024-11-23     Online    AU020860      Walton        CV35   
    377    NGL-094708 2024-05-08   In-Store    AU020860     Kirkton        KW10   
    405    QXS-729355 2024-11-04   In-Store    UD042022      Sutton         RH5   
    443    PET-616268 2024-04-11   In-Store    CX029462     Glasgow          G4   
    487    BDL-819963 2024-01-08   In-Store    OH082802  Birmingham         B12   
    594    ZDT-837295 2024-10-06     Online    MC022478    Kingston        DT10   
    650    SGC-822244 2024-04-14     Online    AU020860       Aston         TF6   
    654    ZUT-785790 2024-01-07     Online    ZE046661   Liverpool         L33   
    659    BEE-491716 2024-11-28   In-Store    LJ093742   Newbiggin        NE46   
    691    AEK-941038 2024-07-11   In-Store    LW071445      London        EC3M   
    750    EZX-980364 2024-07-06     Online    ZE046661   Newbiggin        NE46   
    762    EBM-867691 2024-11-02     Online    LW071445    Whitwell        DL10   
    796    DUC-712298 2024-12-20     Online    AU020860      Weston        GU32   
    813    FWO-432083 2024-03-13   In-Store    ZE046661   Craigavon        BT66   
    911    ECB-497975 2024-03-13   In-Store    LW071445      Walton        CV35   
    938    ECZ-105422 2024-10-24     Online    MC022478       Aston         TF6   
    943    JWH-838061 2024-07-27   In-Store    TW023701   Sheffield          S1   
    988    GBD-331125 2024-05-13     Online    FQ069496     Preston         PR1   
    1004   JKC-753473 2024-01-26     Online    EH051958      Sutton         RH5   
    1111   WGO-397655 2024-02-02   In-Store    WX098476     Newtown        RG20   
    1148   ECX-674753 2024-07-17     Online    NN069494       Upton         WF9   
    1231   IDL-370977 2024-03-04   In-Store    US021421      Weston        GU32   
    1272   RQI-381821 2024-11-14     Online    US021421  Birmingham         B12   
    1396   ITK-586154 2024-01-13     Online    XH043014      Horton        BS37   
    1469   QQE-171296 2024-06-03   In-Store    ZM096349      Milton        NG22   
    1587   YQI-065288 2024-04-03   In-Store    DH074723     Langley         SG4   
    1625   LBG-320882 2024-02-18   In-Store    EH051958  Church End         CB4   
    1641   HUT-691561 2024-07-12   In-Store    EH051958      Norton          S8   
    1885   KRH-100358 2024-01-20   In-Store    TV027066     Tullich        AB55   
    2044   KWU-620560 2025-01-15     Online    XI060063       Leeds         LS6   
    2054   PJI-129995 2025-03-29     Online    AC082690     Carlton         DL8   
    2069   DGC-188810 2025-01-11   In-Store    XJ066938    Bradford         BD7   
    2116   YJC-105237 2025-01-06     Online    UQ060377     Twyford        LE14   
    2127   SNB-741655 2025-02-24   In-Store    YO052337    Charlton        OX12   
    2194   MIK-949841 2025-03-27     Online    FR008830      Linton        BD23   
    2278   DLQ-187253 2025-02-19     Online    WL011058  Whitchurch        BS14   
    2299   XEE-767221 2025-02-07   In-Store    EO027251     Tullich        AB55   
    2371   HAQ-480144 2025-02-15   In-Store    IT060395   Newbiggin        NE46   
    2378   PEA-344352 2025-01-24     Online    KX027147   Sheffield          S1   
    2436   IWS-134045 2025-01-22     Online    EE025228      Hatton        CV35   
    2461   JDB-318018 2025-03-04   In-Store    FL017847       Leeds         LS6   
    2571   BAE-231589 2025-01-16   In-Store    EA084656      Sutton        CT15   
    2624   MGX-478176 2025-02-05     Online    FQ085678   Newbiggin        NE46   
    2631   DVV-308788 2025-01-19   In-Store    BS091864     Langley         SG4   
    2731   BFX-990291 2025-02-20   In-Store    WM098875     Langley         SG4   
    2945   JWL-443647 2025-03-26   In-Store    IA056476      Norton          S8   
    3068   VKF-284488 2024-08-11     Online    TB042465      Sutton        CT15   
    3081   ERU-949207 2024-02-26   In-Store    TB042465   Liverpool         L33   
    3125   ZAG-531130 2024-01-03   In-Store    QJ084755      London        EC1V   
    3220   RSJ-666852 2024-03-15     Online    XM072486  Whitchurch        BS14   
    3288   GIN-165949 2024-06-24     Online    WP034593    Whitwell        DL10   
    3320   NFW-938254 2024-12-21     Online    SH096153      London        EC1V   
    3444   KKF-032786 2024-03-31     Online    WP034593    Bradford         BD7   
    3488   ONX-450313 2024-07-12     Online    XM072486      Weston        GU32   
    3586   HMA-493254 2024-01-25     Online    NI013452      Milton        NG22   
    3598   LXN-635094 2024-09-05     Online    QJ084755      Horton        BS37   
    3757   WDD-602015 2024-07-25   In-Store    QJ084755      Sutton        CT15   
    3892   ZYE-510287 2024-12-23     Online    TE030347      Milton        NG22   
    3896   HFF-859914 2024-12-26     Online    UY018382     Kirkton        KW10   
    3901   HVQ-740227 2024-04-09   In-Store    TE030347    East End        BH21   
    4028   OFB-020382 2024-12-09     Online    QU063405   Middleton        LE16   
    4195   BEC-725501 2024-08-27   In-Store    QY078216      London        WC1B   
    4298   DXV-467907 2024-05-08     Online    QY002140    Kingston        DT10   
    4383   EKN-121943 2024-07-13   In-Store    YU070239   Liverpool         L33   
    4441   KAA-918442 2024-04-21   In-Store    QM060761      Thorpe        BD23   
    4476   ERN-144040 2024-08-28     Online    RP059991      Thorpe        BD23   
    4520   UCP-617833 2024-09-22     Online    SG097274    Kingston        DT10   
    4641   HBC-687256 2024-11-17   In-Store    JU085959  Birmingham         B40   
    4652   COL-778719 2024-01-03     Online    QO062851     Bristol        BS41   
    4715   VGV-861947 2024-04-08   In-Store    UZ096866      London        EC3M   
    4865   BUE-241350 2024-06-30   In-Store    BC050160     Carlton         DL8   
    4883   IRP-944208 2024-07-09   In-Store    UU060530     Newtown        RG20   
    4891   PTX-991530 2024-04-07   In-Store    XY062082      Ashley        SN13   
    5050   JVW-017814 2023-02-27     Online    TW023701      Weston        GU32   
    5082   BWC-162112 2023-07-14     Online    FQ069496       Eaton        DN22   
    5098   XNP-842449 2023-12-02     Online    EY021607      London        EC1V   
    5122   SLD-991246 2023-09-15     Online    ZE046661  Stapleford         LN6   
    5151   LFU-280437 2023-05-04   In-Store    EY021607      Wirral        CH48   
    5201   ELJ-090666 2023-04-26   In-Store    TW023701    Kingston        DT10   
    5282   QMN-249473 2023-07-28     Online    TW023701      London        WC1B   
    5375   NFK-370329 2023-03-21   In-Store    OH082802      London         W1F   
    5424   ZNB-022087 2023-10-08     Online    LJ093742    West End        DN36   
    5427   MWZ-787646 2023-10-20   In-Store    ZE046661    Brampton        NR34   
    5453   RPE-726714 2023-08-18   In-Store    TW023701        Dean         OX7   
    5505   TSL-066010 2023-12-07   In-Store    LJ093742    Kingston        DT10   
    5522   LWH-121078 2023-10-16     Online    MC022478      London         W1F   
    5542   HRY-764699 2023-02-06     Online    PI013145    Bradford         BD7   
    5549   BDM-124180 2023-07-23   In-Store    EY021607   Craigavon        BT66   
    5660   HNT-122280 2023-01-05     Online    CX029462    Buckland        CT16   
    5679   ZCK-791590 2023-06-29   In-Store    UD042022      London        SW1E   
    5731   TXK-954521 2023-04-06   In-Store    FQ069496      Norton          S8   
    5775   OHB-020073 2023-06-28   In-Store    MC022478      Horton        BS37   
    5795   RID-224469 2023-05-25   In-Store    TW023701  Whitchurch        BS14   
    5934   JGL-061318 2023-06-13     Online    AU020860   Normanton        LE15   
    5970   OSL-904573 2023-02-12     Online    FQ069496    East End        BH21   
    5979   CCU-219276 2023-12-25   In-Store    CX029462     Langley         SG4   
    6089   PBW-635147 2023-01-05   In-Store    UI019195    Buckland        CT16   
    6269   XXN-289173 2023-09-08   In-Store    ZM096349      London        EC1V   
    6316   WKF-073318 2023-04-18     Online    UI019195   Middleton        LE16   
    6326   WJR-474067 2023-10-26     Online    ZM096349      Milton        NG22   
    6428   ERI-395213 2023-12-29     Online    GM070527       Upton        DN21   
    6458   KXF-720738 2023-09-14     Online    WZ079454        Ford        GL54   
    6490   YFA-951353 2023-01-16     Online    WZ079454      Norton        NN11   
    6578   PBC-460472 2023-03-23     Online    WZ079454      London        EC3M   
    6594   FHK-675929 2023-05-30     Online    ZM096349     Twyford        LE14   
    6648   WMP-488427 2023-12-22     Online    ZM096349      Sutton        CT15   
    6676   YYL-356926 2023-08-22     Online    ZM096349       Leeds         LS6   
    6746   CII-036160 2023-01-29     Online    DH074723      London         W1F   
    6846   CYV-160261 2023-08-02     Online    ZM096349      Norton        NN11   
    6971   YJN-884649 2023-12-11   In-Store    GM070527    West End        DN36   
    7019   AFZ-453884 2023-10-26   In-Store    UY018382    Burnside        EH52   
    7021   KFH-908636 2023-12-13   In-Store    XM072486    Whitwell        DL10   
    7038   BAE-918331 2023-06-12     Online    WP034593     Kirkton        KW10   
    7170   XQD-675118 2023-11-10     Online    PP030760   Edinburgh         EH9   
    7236   UCY-713868 2023-03-05     Online    PP030760    East End        BH21   
    7246   KZY-082586 2023-03-30     Online    TB042465   Edinburgh         EH9   
    7279   LLB-794370 2023-09-02   In-Store    XM072486       Aston         TF6   
    7282   EUF-170432 2023-07-22     Online    OY080109      London        WC2H   
    7289   CVS-573479 2023-03-18   In-Store    PQ067744      Weston        GU32   
    7298   FIJ-224687 2023-05-23     Online    PP030760        Ford        GL54   
    7378   UAQ-377712 2023-05-08     Online    QJ084755       Aston         TF6   
    7442   HFN-407049 2023-08-03     Online    TB042465       Upton         WF9   
    7498   SAA-295127 2023-12-07     Online    XM072486       Upton        DN21   
    7552   RFY-921704 2023-04-07     Online    BC022440    East End        BH21   
    7553   GGR-307166 2023-10-28   In-Store    OY080109    West End        DN36   
    7559   PHJ-255667 2023-07-24   In-Store    QJ084755     Wootton         NN4   
    7570   HWS-870923 2023-09-05     Online    TB042465    West End        DN36   
    7581   ESM-919576 2023-10-31   In-Store    NI013452      Newton        NG34   
    7778   KVM-578944 2023-10-10     Online    UY018382     Langley         SG4   
    7810   PHZ-224126 2023-03-04     Online    BC022440      Newton        NG34   
    7911   EOR-198729 2023-03-12   In-Store    TB042465      Denton         M34   
    7986   WFZ-950094 2023-08-14     Online    PP030760  Birmingham         B40   
    7996   LXW-911098 2023-03-31     Online    QJ084755     Belfast         BT2   
    7997   VIP-799277 2023-09-30   In-Store    PQ067744     Tullich        AB55   
    8096   RGR-505331 2023-03-09     Online    HQ027283       Leeds         LS6   
    8098   BUP-976275 2023-11-02     Online    HV041002       Upton        DN21   
    8211   JKF-877169 2023-04-24   In-Store    BO048558     Twyford        LE14   
    8375   QDK-644128 2023-11-06   In-Store    XC025583     Wootton         NN4   
    8512   CRO-381790 2023-06-12     Online    QN007877      Ashley        SN13   
    8564   HUS-915157 2023-09-12     Online    YG019226        Dean         OX7   
    8616   WDZ-856215 2023-02-05     Online    YD003006   Craigavon        BT66   
    8620   KZO-191391 2023-07-01     Online    YT004530       Upton        DN21   
    8632   HIS-683651 2023-09-08     Online    HX021080      Seaton        LE15   
    8691   ETQ-236315 2023-04-28   In-Store    OA062579       Eaton        DN22   
    8861   BUJ-744889 2023-11-18   In-Store    MG061805     Tullich        AB55   
    8937   AGB-861436 2023-05-09   In-Store    JS031511    Aberdeen        AB39   
    9042   AHF-972734 2024-12-21     Online    TB042465    Brampton        NR34   
    9086   HQN-270650 2024-08-06     Online    TB042465      Sutton         RH5   
    9154   NNT-754867 2025-03-29     Online    OY080109     Swindon         SN1   
    9243   GMG-048991 2024-11-02     Online    QJ084755     Kirkton        KW10   
    9276   SYP-574723 2024-07-03     Online    QJ084755     Newtown        RG20   
    9332   XBC-381805 2024-03-24     Online    UY018382    Kingston        DT10   
    9341   XIQ-931395 2025-01-09   In-Store    OY080109      London         W1F   
    9485   BBN-136502 2024-09-06     Online    SH096153    West End        DN36   
    9493   SGR-528892 2024-04-22     Online    PQ067744      London        EC3M   
    9564   ICC-260157 2024-02-05   In-Store    GS076409      Newton         IV1   
    9608   DCG-112066 2024-01-06     Online    QJ084755   Liverpool         L74   
    9619   XTC-364202 2024-10-29     Online    PP030760  Birmingham         B12   
    9629   GFT-452274 2025-03-18     Online    TB042465     Preston         PR1   
    9685   LJA-153618 2024-07-06     Online    TE030347      Thorpe        BD23   
    9686   JSS-622623 2024-01-06     Online    QJ084755     Langley         SG4   
    9800   WCI-313122 2024-06-08     Online    GS076409       Upton         WF9   
    9851   ALD-231231 2025-03-06   In-Store    WP034593    Kingston        DT10   
    9860   HDI-801904 2024-09-21     Online    NI013452     Langley         SG4   
    9893   JCD-623875 2024-05-25     Online    UY018382      Pentre         SY4   
    9917   ACN-113893 2024-12-11     Online    BC022440        Ford        GL54   
    9991   CYF-342605 2024-08-24     Online    XM072486     Belfast         BT2   
    9995   XZU-546546 2024-04-02     Online    WP034593      Norton          S8   
    10018  LCD-697614 2024-01-20     Online    TB042465     Newport        NR29   
    10027  IME-134226 2023-11-29   In-Store    WP034593      Merton        SW19   
    10172  JSU-016488 2023-09-27     Online    XM072486  Birmingham         B40   
    10181  APK-675634 2023-03-28   In-Store    WP034593     Newtown        RG20   
    10189  KTM-235219 2023-07-01   In-Store    NI013452      Wirral        CH48   
    10225  YTD-253528 2024-01-11   In-Store    NI013452    Whitwell        DL10   
    10315  ZKK-199291 2023-12-02   In-Store    PP030760     Tullich        AB55   
    10331  IZJ-441510 2024-11-18   In-Store    BC022440       Eaton        DN22   
    10377  ZZL-066466 2024-07-28   In-Store    PP030760      London        EC1V   
    10451  LAH-895983 2024-06-26   In-Store    OY080109      London        SW1E   
    10534  WSZ-551954 2024-04-13     Online    GS076409      Norton        NN11   
    10549  UUK-655641 2024-07-05   In-Store    XM072486      Pentre         SY4   
    10628  HBT-366362 2024-04-13     Online    XM072486     Swindon         SN1   
    10640  XAF-128932 2024-08-04     Online    OY080109  Manchester         M14   
    10650  XNX-186060 2024-05-09     Online    WP034593      Pentre         SY4   
    10657  CRP-847123 2024-09-05   In-Store    SH096153      London        SW1E   
    10679  MOY-618909 2023-12-18   In-Store    PQ067744   Edinburgh         EH9   
    10706  NMX-569582 2024-06-09     Online    TB042465     Newtown        RG20   
    10709  IMQ-422138 2023-10-18   In-Store    TE030347   Liverpool         L33   
    10790  GSS-908566 2024-06-13     Online    BC022440       Aston         TF6   
    10857  TNB-413189 2024-04-27   In-Store    UY018382    Burnside        EH52   
    10858  HTL-984269 2024-09-10     Online    TB042465   Craigavon        BT66   
    10924  NLD-783846 2023-02-21     Online    PQ067744       Aston         TF6   
    10940  ZRL-578874 2024-04-02     Online    BC022440     Glasgow          G4   
    10984  JTF-677341 2024-07-26     Online    TB042465   Craigavon        BT66   
    
                    Country                    Region                  Product ID  \
    41              England                South West  01JZ3N50ESGK3P4RR5Z0YF0ESD   
    152               Wales                   unknown  01JZ3N55VSJMMDRYMXXA19JG7M   
    187             England                North West  01JZ3N55ZCM1H50JM2ZZ2RGRXB   
    192             England                   unknown  01JZ3N53FB041Z827WE4SCE0SX   
    248             England             East Midlands  01JZ3N54W7XW2ZMB9TMV78GWYC   
    334             England                   unknown  01JZ3N54W7XW2ZMB9TMV78GWYC   
    377            Scotland                   unknown  01JZ3N54W7XW2ZMB9TMV78GWYC   
    405             England                South East  01JZ3N50MVCXS99CC73H3HP5XT   
    443            Scotland                   unknown  01JZ3N53FB041Z827WE4SCE0SX   
    487             England                    London  01JZ3N568YWQMTWCGZ1HV96YR3   
    594             England                North West  01JZ3N50ESGK3P4RR5Z0YF0ESD   
    650             England                North West  01JZ3N54W7XW2ZMB9TMV78GWYC   
    654             England                North West  01JZ3N561GF35WBV99GWRG4S82   
    659             England             East Midlands  01JZ3N50CWYA7WEYZMFE108BQP   
    691             England                North West  01JZ3N55VSJMMDRYMXXA19JG7M   
    750             England  Yorkshire and the Humber  01JZ3N561GF35WBV99GWRG4S82   
    762             England                    London  01JZ3N55VSJMMDRYMXXA19JG7M   
    796             England             East Midlands  01JZ3N54W7XW2ZMB9TMV78GWYC   
    813    Northern Ireland                   unknown  01JZ3N561GF35WBV99GWRG4S82   
    911             England                North West  01JZ3N55VSJMMDRYMXXA19JG7M   
    938             England                   unknown  01JZ3N50ESGK3P4RR5Z0YF0ESD   
    943             England             West Midlands  01JZ3N5519WGMKBKJ806V54SNA   
    988             England  Yorkshire and the Humber  01JZ3N51WA4J6K3NJAHGZ77S13   
    1004            England             East Midlands  01JZ3NT0G2KA577CYDQJYBPM01   
    1111            England             West Midlands  01JZ3NR4GWSBB8JK7S9CM60J6A   
    1148            England             West Midlands  01JZ3NCFQWMEND7FMSNNWS4FRH   
    1231            England           East of England  01JZ3NT2SB73VJH28QM38EE8CC   
    1272            England           East of England  01JZ3NT2SB73VJH28QM38EE8CC   
    1396            England           East of England  01JZ3NCGGNV43TBZ4RESW0ZVE5   
    1469            England             West Midlands  01JZ3NTAWDN18VKEF89NEMSDJX   
    1587            England                   unknown  01JZ3NSXFNNKZ42D4KCN7Y9GSJ   
    1625            England  Yorkshire and the Humber  01JZ3NT0G2KA577CYDQJYBPM01   
    1641            England                North East  01JZ3NT0G2KA577CYDQJYBPM01   
    1885           Scotland                   unknown  01JZ3NTJ6EQF9D5KJ11G9QMX2W   
    2044            England           East of England  01JZ3NC9JWB0J9QBNBQQS9ZRY7   
    2054            England                    London  01JZ3NR4GWSBB8JK7S9CM60J6A   
    2069            England                South East  01JZ3NT2SB73VJH28QM38EE8CC   
    2116            England             West Midlands  01JZ3NTJ6EQF9D5KJ11G9QMX2W   
    2127            England  Yorkshire and the Humber  01JZ3NC9JWB0J9QBNBQQS9ZRY7   
    2194            England                    London  01JZ3NC9JWB0J9QBNBQQS9ZRY7   
    2278            England           East of England  01JZ3NTJ6EQF9D5KJ11G9QMX2W   
    2299           Scotland                   unknown  01JZ3NCFQWMEND7FMSNNWS4FRH   
    2371            England             West Midlands  01JZ3NTJ6EQF9D5KJ11G9QMX2W   
    2378            England             West Midlands  01JZ3NT0G2KA577CYDQJYBPM01   
    2436            England                North East  01JZ3NCF5XZ4XKCH8GA8QR4A4G   
    2461            England           East of England  01JZ3NT3DZNMWT1JQS7XFA880R   
    2571            England           East of England  01JZ3NT0G2KA577CYDQJYBPM01   
    2624            England                   unknown  01JZ3NT0G2KA577CYDQJYBPM01   
    2631            England                South East  01JZ3NC9JWB0J9QBNBQQS9ZRY7   
    2731            England                   unknown  01JZ3NTJ6EQF9D5KJ11G9QMX2W   
    2945            England                South East  01JZ3NSXFNNKZ42D4KCN7Y9GSJ   
    3068            England                    London  01JZ3N5BWW7QMY5E7VDFH72XD6   
    3081            England                    London  01JZ3N5BWW7QMY5E7VDFH72XD6   
    3125            England           East of England  01JZ3N5C2EB7MTZZYJMR2ZK923   
    3220            England                North West  01JZ3NC4WZH3PN7HP3JGNVZ396   
    3288            England                   unknown  01JZ3NC42NMJYK1GNC236DHSQ7   
    3320            England           East of England  01JZ3N57MP7Z5WPWTSDA7K74ZX   
    3444            England                North West  01JZ3NC42NMJYK1GNC236DHSQ7   
    3488            England             West Midlands  01JZ3NC4WZH3PN7HP3JGNVZ396   
    3586            England                   unknown  01JZ3N5C0G9W05PNAX4C3HYZF8   
    3598            England                    London  01JZ3N5C2EB7MTZZYJMR2ZK923   
    3757            England             East Midlands  01JZ3N5C2EB7MTZZYJMR2ZK923   
    3892            England                   unknown  01JZ3N58EY6687PMM5C4TMXBG6   
    3896           Scotland                   unknown  01JZ3N57533PWPRPPXQ2WD1D6E   
    3901            England                South East  01JZ3N58EY6687PMM5C4TMXBG6   
    4028            England                    London  01JZ3NR4GWSBB8JK7S9CM60J6A   
    4195            England             West Midlands  01JZ3NR4GWSBB8JK7S9CM60J6A   
    4298            England             West Midlands  01JZ3NCF5XZ4XKCH8GA8QR4A4G   
    4383            England                   unknown  01JZ3NT3DZNMWT1JQS7XFA880R   
    4441            England                    London  01JZ3NSXFNNKZ42D4KCN7Y9GSJ   
    4476            England  Yorkshire and the Humber  01JZ3NT0G2KA577CYDQJYBPM01   
    4520            England                South East  01JZ3NT0G2KA577CYDQJYBPM01   
    4641            England             East Midlands  01JZ3NSXFNNKZ42D4KCN7Y9GSJ   
    4652            England           East of England  01JZ3NR4GWSBB8JK7S9CM60J6A   
    4715            England             East Midlands  01JZ3NT0G2KA577CYDQJYBPM01   
    4865            England                North East  01JZ3NCF5XZ4XKCH8GA8QR4A4G   
    4883            England                South East  01JZ3NTJ6EQF9D5KJ11G9QMX2W   
    4891            England                North West  01JZ3NR4GWSBB8JK7S9CM60J6A   
    5050            England                North West  01JZ3N5519WGMKBKJ806V54SNA   
    5082            England                South West  01JZ3N51WA4J6K3NJAHGZ77S13   
    5098            England                South East  01JZ3N55ZCM1H50JM2ZZ2RGRXB   
    5122            England           East of England  01JZ3N561GF35WBV99GWRG4S82   
    5151            England                South West  01JZ3N55ZCM1H50JM2ZZ2RGRXB   
    5201            England             West Midlands  01JZ3N5519WGMKBKJ806V54SNA   
    5282            England             West Midlands  01JZ3N5519WGMKBKJ806V54SNA   
    5375            England             West Midlands  01JZ3N568YWQMTWCGZ1HV96YR3   
    5424            England                   unknown  01JZ3N50CWYA7WEYZMFE108BQP   
    5427            England                North East  01JZ3N561GF35WBV99GWRG4S82   
    5453            England                    London  01JZ3N5519WGMKBKJ806V54SNA   
    5505            England                North West  01JZ3N50CWYA7WEYZMFE108BQP   
    5522            England                North East  01JZ3N50ESGK3P4RR5Z0YF0ESD   
    5542            England                North East  01JZ3N50JYB2FEYPZ6DJEM8PN3   
    5549   Northern Ireland                   unknown  01JZ3N55ZCM1H50JM2ZZ2RGRXB   
    5660            England                North West  01JZ3N53FB041Z827WE4SCE0SX   
    5679            England                South West  01JZ3N50MVCXS99CC73H3HP5XT   
    5731            England             West Midlands  01JZ3N51WA4J6K3NJAHGZ77S13   
    5775            England                North East  01JZ3N50ESGK3P4RR5Z0YF0ESD   
    5795            England  Yorkshire and the Humber  01JZ3N5519WGMKBKJ806V54SNA   
    5934            England             East Midlands  01JZ3N54W7XW2ZMB9TMV78GWYC   
    5970            England                North East  01JZ3N51WA4J6K3NJAHGZ77S13   
    5979            England                South East  01JZ3N53FB041Z827WE4SCE0SX   
    6089            England                South West  01JZ3NCF5XZ4XKCH8GA8QR4A4G   
    6269            England                South West  01JZ3NTAWDN18VKEF89NEMSDJX   
    6316            England             West Midlands  01JZ3NCF5XZ4XKCH8GA8QR4A4G   
    6326            England                South West  01JZ3NTAWDN18VKEF89NEMSDJX   
    6428            England                   unknown  01JZ3NC9JWB0J9QBNBQQS9ZRY7   
    6458            England             West Midlands  01JZ3NT3DZNMWT1JQS7XFA880R   
    6490            England                   unknown  01JZ3NT3DZNMWT1JQS7XFA880R   
    6578            England  Yorkshire and the Humber  01JZ3NT3DZNMWT1JQS7XFA880R   
    6594            England                North West  01JZ3NTAWDN18VKEF89NEMSDJX   
    6648            England                North East  01JZ3NTAWDN18VKEF89NEMSDJX   
    6676            England             West Midlands  01JZ3NTAWDN18VKEF89NEMSDJX   
    6746            England  Yorkshire and the Humber  01JZ3NSXFNNKZ42D4KCN7Y9GSJ   
    6846            England             West Midlands  01JZ3NTAWDN18VKEF89NEMSDJX   
    6971            England                North West  01JZ3NC9JWB0J9QBNBQQS9ZRY7   
    7019           Scotland                   unknown  01JZ3N57533PWPRPPXQ2WD1D6E   
    7021            England                North West  01JZ3NC4WZH3PN7HP3JGNVZ396   
    7038            England                South West  01JZ3NC42NMJYK1GNC236DHSQ7   
    7170           Scotland                   unknown  01JZ3N57FE6EZPS6YSR0TGVYRV   
    7236            England                South East  01JZ3N57FE6EZPS6YSR0TGVYRV   
    7246           Scotland                   unknown  01JZ3N5BWW7QMY5E7VDFH72XD6   
    7279            England                   unknown  01JZ3NC4WZH3PN7HP3JGNVZ396   
    7282            England             East Midlands  01JZ3N593PJ33XRK9XY4938FE5   
    7289            England           East of England  01JZ3NC7K14YWSKC0WT9JRQJ0A   
    7298            England  Yorkshire and the Humber  01JZ3N57FE6EZPS6YSR0TGVYRV   
    7378            England                North West  01JZ3N5C2EB7MTZZYJMR2ZK923   
    7442            England                South West  01JZ3N5BWW7QMY5E7VDFH72XD6   
    7498            England  Yorkshire and the Humber  01JZ3NC4WZH3PN7HP3JGNVZ396   
    7552            England             East Midlands  01JZ3N57XVWGAGBA0RBA85W0C4   
    7553            England                North West  01JZ3N593PJ33XRK9XY4938FE5   
    7559            England                North East  01JZ3N5C2EB7MTZZYJMR2ZK923   
    7570            England                North East  01JZ3N5BWW7QMY5E7VDFH72XD6   
    7581            England                    London  01JZ3N5C0G9W05PNAX4C3HYZF8   
    7778            England             East Midlands  01JZ3N57533PWPRPPXQ2WD1D6E   
    7810            England                North West  01JZ3N57XVWGAGBA0RBA85W0C4   
    7911            England                   unknown  01JZ3N5BWW7QMY5E7VDFH72XD6   
    7986            England           East of England  01JZ3N57FE6EZPS6YSR0TGVYRV   
    7996   Northern Ireland                   unknown  01JZ3N5C2EB7MTZZYJMR2ZK923   
    7997           Scotland                   unknown  01JZ3NC7K14YWSKC0WT9JRQJ0A   
    8096            England                South West  01JZ3NSXFNNKZ42D4KCN7Y9GSJ   
    8098            England                    London  01JZ3NCFQWMEND7FMSNNWS4FRH   
    8211            England           East of England  01JZ3NCFQWMEND7FMSNNWS4FRH   
    8375            England           East of England  01JZ3NT0G2KA577CYDQJYBPM01   
    8512            England             East Midlands  01JZ3NCF5XZ4XKCH8GA8QR4A4G   
    8564            England                South East  01JZ3NCFQWMEND7FMSNNWS4FRH   
    8616   Northern Ireland                   unknown  01JZ3NT3DZNMWT1JQS7XFA880R   
    8620            England           East of England  01JZ3NC9JWB0J9QBNBQQS9ZRY7   
    8632            England  Yorkshire and the Humber  01JZ3NR4GWSBB8JK7S9CM60J6A   
    8691            England             East Midlands  01JZ3NR4GWSBB8JK7S9CM60J6A   
    8861           Scotland                   unknown  01JZ3NR4GWSBB8JK7S9CM60J6A   
    8937           Scotland                   unknown  01JZ3NT0G2KA577CYDQJYBPM01   
    9042            England                South West  01JZ3N5BWW7QMY5E7VDFH72XD6   
    9086            England                   unknown  01JZ3N5BWW7QMY5E7VDFH72XD6   
    9154            England                   unknown  01JZ3N593PJ33XRK9XY4938FE5   
    9243           Scotland                   unknown  01JZ3N5C2EB7MTZZYJMR2ZK923   
    9276            England             East Midlands  01JZ3N5C2EB7MTZZYJMR2ZK923   
    9332            England             West Midlands  01JZ3N57533PWPRPPXQ2WD1D6E   
    9341            England                North East  01JZ3N593PJ33XRK9XY4938FE5   
    9485            England                South West  01JZ3N57MP7Z5WPWTSDA7K74ZX   
    9493            England                South West  01JZ3NC7K14YWSKC0WT9JRQJ0A   
    9564           Scotland                   unknown  01JZ3NC53H785J2CMK3CFD8YNQ   
    9608            England             East Midlands  01JZ3N5C2EB7MTZZYJMR2ZK923   
    9619            England                South East  01JZ3N57FE6EZPS6YSR0TGVYRV   
    9629            England                North East  01JZ3N5BWW7QMY5E7VDFH72XD6   
    9685            England             West Midlands  01JZ3N58EY6687PMM5C4TMXBG6   
    9686            England             East Midlands  01JZ3N5C2EB7MTZZYJMR2ZK923   
    9800            England                South East  01JZ3NC53H785J2CMK3CFD8YNQ   
    9851            England                North East  01JZ3NC42NMJYK1GNC236DHSQ7   
    9860            England                    London  01JZ3N5C0G9W05PNAX4C3HYZF8   
    9893              Wales                   unknown  01JZ3N57533PWPRPPXQ2WD1D6E   
    9917            England             East Midlands  01JZ3N57XVWGAGBA0RBA85W0C4   
    9991   Northern Ireland                   unknown  01JZ3NC4WZH3PN7HP3JGNVZ396   
    9995            England                South West  01JZ3NC42NMJYK1GNC236DHSQ7   
    10018           England                North East  01JZ3N5BWW7QMY5E7VDFH72XD6   
    10027           England                South East  01JZ3NC42NMJYK1GNC236DHSQ7   
    10172           England           East of England  01JZ3NC4WZH3PN7HP3JGNVZ396   
    10181           England             East Midlands  01JZ3NC42NMJYK1GNC236DHSQ7   
    10189           England  Yorkshire and the Humber  01JZ3N5C0G9W05PNAX4C3HYZF8   
    10225           England                   unknown  01JZ3N5C0G9W05PNAX4C3HYZF8   
    10315          Scotland                   unknown  01JZ3N57FE6EZPS6YSR0TGVYRV   
    10331           England                   unknown  01JZ3N57XVWGAGBA0RBA85W0C4   
    10377           England                   unknown  01JZ3N57FE6EZPS6YSR0TGVYRV   
    10451           England                North West  01JZ3N593PJ33XRK9XY4938FE5   
    10534           England                South West  01JZ3NC53H785J2CMK3CFD8YNQ   
    10549             Wales                   unknown  01JZ3NC4WZH3PN7HP3JGNVZ396   
    10628           England                   unknown  01JZ3NC4WZH3PN7HP3JGNVZ396   
    10640           England                North West  01JZ3N593PJ33XRK9XY4938FE5   
    10650             Wales                   unknown  01JZ3NC42NMJYK1GNC236DHSQ7   
    10657           England                   unknown  01JZ3N57MP7Z5WPWTSDA7K74ZX   
    10679          Scotland                   unknown  01JZ3NC7K14YWSKC0WT9JRQJ0A   
    10706           England                South East  01JZ3N5BWW7QMY5E7VDFH72XD6   
    10709           England                South East  01JZ3N58EY6687PMM5C4TMXBG6   
    10790           England                North West  01JZ3N57XVWGAGBA0RBA85W0C4   
    10857          Scotland                   unknown  01JZ3N57533PWPRPPXQ2WD1D6E   
    10858  Northern Ireland                   unknown  01JZ3N5BWW7QMY5E7VDFH72XD6   
    10924           England                South West  01JZ3NC7K14YWSKC0WT9JRQJ0A   
    10940          Scotland                   unknown  01JZ3N57XVWGAGBA0RBA85W0C4   
    10984  Northern Ireland                   unknown  01JZ3N5BWW7QMY5E7VDFH72XD6   
    
                                         Product Name Category  \
    41                              Greek Feta Cheese      NaN   
    152                          Smartphone Projector      NaN   
    187                        Dark Chocolate Raisins      NaN   
    192                  Chocolate Peanut Butter Cups      NaN   
    248                         Garlic Herb Seasoning      NaN   
    334                         Garlic Herb Seasoning      NaN   
    377                         Garlic Herb Seasoning      NaN   
    405           Eco-Friendly Stainless Steel Straws      NaN   
    443                  Chocolate Peanut Butter Cups      NaN   
    487    LED Flashlight with Rechargeable Batteries      NaN   
    594                             Greek Feta Cheese      NaN   
    650                         Garlic Herb Seasoning      NaN   
    654                             Portable Speakers      NaN   
    659                         Electric Butter Churn      NaN   
    691                          Smartphone Projector      NaN   
    750                             Portable Speakers      NaN   
    762                          Smartphone Projector      NaN   
    796                         Garlic Herb Seasoning      NaN   
    813                             Portable Speakers      NaN   
    911                          Smartphone Projector      NaN   
    938                             Greek Feta Cheese      NaN   
    943                                  Chino Shorts      NaN   
    988                           Chili Con Carne Mix      NaN   
    1004                        Whole Roasted Chicken      NaN   
    1111                 Biodegradable Dog Waste Bags      NaN   
    1148                    Portable Phone Mug Holder      NaN   
    1231                             Weighted Blanket      NaN   
    1272                             Weighted Blanket      NaN   
    1396                              USB Flash Drive      NaN   
    1469                       Digital Voice Recorder      NaN   
    1587                           Green Smoothie Mix      NaN   
    1625                        Whole Roasted Chicken      NaN   
    1641                        Whole Roasted Chicken      NaN   
    1885             Plant-Based Meal Prep Containers      NaN   
    2044                      Smart Wi-Fi Light Bulbs      NaN   
    2054                 Biodegradable Dog Waste Bags      NaN   
    2069                             Weighted Blanket      NaN   
    2116             Plant-Based Meal Prep Containers      NaN   
    2127                      Smart Wi-Fi Light Bulbs      NaN   
    2194                      Smart Wi-Fi Light Bulbs      NaN   
    2278             Plant-Based Meal Prep Containers      NaN   
    2299                    Portable Phone Mug Holder      NaN   
    2371             Plant-Based Meal Prep Containers      NaN   
    2378                        Whole Roasted Chicken      NaN   
    2436                    Multi-Purpose Marine Rope      NaN   
    2461                        Peanut Butter Granola      NaN   
    2571                        Whole Roasted Chicken      NaN   
    2624                        Whole Roasted Chicken      NaN   
    2631                      Smart Wi-Fi Light Bulbs      NaN   
    2731             Plant-Based Meal Prep Containers      NaN   
    2945                           Green Smoothie Mix      NaN   
    3068                                 Multi-Cooker      NaN   
    3081                                 Multi-Cooker      NaN   
    3125                              Sunflower Seeds      NaN   
    3220                               Electric Razor      NaN   
    3288                     Portable Air Conditioner      NaN   
    3320                       Aeropress Coffee Maker      NaN   
    3444                     Portable Air Conditioner      NaN   
    3488                               Electric Razor      NaN   
    3586                               Organic Quinoa      NaN   
    3598                              Sunflower Seeds      NaN   
    3757                              Sunflower Seeds      NaN   
    3892                     Almond Flour Pancake Mix      NaN   
    3896               Cat Tree with Scratching Posts      NaN   
    3901                     Almond Flour Pancake Mix      NaN   
    4028                 Biodegradable Dog Waste Bags      NaN   
    4195                 Biodegradable Dog Waste Bags      NaN   
    4298                    Multi-Purpose Marine Rope      NaN   
    4383                        Peanut Butter Granola      NaN   
    4441                           Green Smoothie Mix      NaN   
    4476                        Whole Roasted Chicken      NaN   
    4520                        Whole Roasted Chicken      NaN   
    4641                           Green Smoothie Mix      NaN   
    4652                 Biodegradable Dog Waste Bags      NaN   
    4715                        Whole Roasted Chicken      NaN   
    4865                    Multi-Purpose Marine Rope      NaN   
    4883             Plant-Based Meal Prep Containers      NaN   
    4891                 Biodegradable Dog Waste Bags      NaN   
    5050                                 Chino Shorts      NaN   
    5082                          Chili Con Carne Mix      NaN   
    5098                       Dark Chocolate Raisins      NaN   
    5122                            Portable Speakers      NaN   
    5151                       Dark Chocolate Raisins      NaN   
    5201                                 Chino Shorts      NaN   
    5282                                 Chino Shorts      NaN   
    5375   LED Flashlight with Rechargeable Batteries      NaN   
    5424                        Electric Butter Churn      NaN   
    5427                            Portable Speakers      NaN   
    5453                                 Chino Shorts      NaN   
    5505                        Electric Butter Churn      NaN   
    5522                            Greek Feta Cheese      NaN   
    5542                         Organic Quinoa Salad      NaN   
    5549                       Dark Chocolate Raisins      NaN   
    5660                 Chocolate Peanut Butter Cups      NaN   
    5679          Eco-Friendly Stainless Steel Straws      NaN   
    5731                          Chili Con Carne Mix      NaN   
    5775                            Greek Feta Cheese      NaN   
    5795                                 Chino Shorts      NaN   
    5934                        Garlic Herb Seasoning      NaN   
    5970                          Chili Con Carne Mix      NaN   
    5979                 Chocolate Peanut Butter Cups      NaN   
    6089                    Multi-Purpose Marine Rope      NaN   
    6269                       Digital Voice Recorder      NaN   
    6316                    Multi-Purpose Marine Rope      NaN   
    6326                       Digital Voice Recorder      NaN   
    6428                      Smart Wi-Fi Light Bulbs      NaN   
    6458                        Peanut Butter Granola      NaN   
    6490                        Peanut Butter Granola      NaN   
    6578                        Peanut Butter Granola      NaN   
    6594                       Digital Voice Recorder      NaN   
    6648                       Digital Voice Recorder      NaN   
    6676                       Digital Voice Recorder      NaN   
    6746                           Green Smoothie Mix      NaN   
    6846                       Digital Voice Recorder      NaN   
    6971                      Smart Wi-Fi Light Bulbs      NaN   
    7019               Cat Tree with Scratching Posts      NaN   
    7021                               Electric Razor      NaN   
    7038                     Portable Air Conditioner      NaN   
    7170                          Hibiscus Herbal Tea      NaN   
    7236                          Hibiscus Herbal Tea      NaN   
    7246                                 Multi-Cooker      NaN   
    7279                               Electric Razor      NaN   
    7282                      Outdoor Sports Backpack      NaN   
    7289                        Organic Coconut Flour      NaN   
    7298                          Hibiscus Herbal Tea      NaN   
    7378                              Sunflower Seeds      NaN   
    7442                                 Multi-Cooker      NaN   
    7498                               Electric Razor      NaN   
    7552                              Spicy BBQ Sauce      NaN   
    7553                      Outdoor Sports Backpack      NaN   
    7559                              Sunflower Seeds      NaN   
    7570                                 Multi-Cooker      NaN   
    7581                               Organic Quinoa      NaN   
    7778               Cat Tree with Scratching Posts      NaN   
    7810                              Spicy BBQ Sauce      NaN   
    7911                                 Multi-Cooker      NaN   
    7986                          Hibiscus Herbal Tea      NaN   
    7996                              Sunflower Seeds      NaN   
    7997                        Organic Coconut Flour      NaN   
    8096                           Green Smoothie Mix      NaN   
    8098                    Portable Phone Mug Holder      NaN   
    8211                    Portable Phone Mug Holder      NaN   
    8375                        Whole Roasted Chicken      NaN   
    8512                    Multi-Purpose Marine Rope      NaN   
    8564                    Portable Phone Mug Holder      NaN   
    8616                        Peanut Butter Granola      NaN   
    8620                      Smart Wi-Fi Light Bulbs      NaN   
    8632                 Biodegradable Dog Waste Bags      NaN   
    8691                 Biodegradable Dog Waste Bags      NaN   
    8861                 Biodegradable Dog Waste Bags      NaN   
    8937                        Whole Roasted Chicken      NaN   
    9042                                 Multi-Cooker      NaN   
    9086                                 Multi-Cooker      NaN   
    9154                      Outdoor Sports Backpack      NaN   
    9243                              Sunflower Seeds      NaN   
    9276                              Sunflower Seeds      NaN   
    9332               Cat Tree with Scratching Posts      NaN   
    9341                      Outdoor Sports Backpack      NaN   
    9485                       Aeropress Coffee Maker      NaN   
    9493                        Organic Coconut Flour      NaN   
    9564                          Whole Grain Mustard      NaN   
    9608                              Sunflower Seeds      NaN   
    9619                          Hibiscus Herbal Tea      NaN   
    9629                                 Multi-Cooker      NaN   
    9685                     Almond Flour Pancake Mix      NaN   
    9686                              Sunflower Seeds      NaN   
    9800                          Whole Grain Mustard      NaN   
    9851                     Portable Air Conditioner      NaN   
    9860                               Organic Quinoa      NaN   
    9893               Cat Tree with Scratching Posts      NaN   
    9917                              Spicy BBQ Sauce      NaN   
    9991                               Electric Razor      NaN   
    9995                     Portable Air Conditioner      NaN   
    10018                                Multi-Cooker      NaN   
    10027                    Portable Air Conditioner      NaN   
    10172                              Electric Razor      NaN   
    10181                    Portable Air Conditioner      NaN   
    10189                              Organic Quinoa      NaN   
    10225                              Organic Quinoa      NaN   
    10315                         Hibiscus Herbal Tea      NaN   
    10331                             Spicy BBQ Sauce      NaN   
    10377                         Hibiscus Herbal Tea      NaN   
    10451                     Outdoor Sports Backpack      NaN   
    10534                         Whole Grain Mustard      NaN   
    10549                              Electric Razor      NaN   
    10628                              Electric Razor      NaN   
    10640                     Outdoor Sports Backpack      NaN   
    10650                    Portable Air Conditioner      NaN   
    10657                      Aeropress Coffee Maker      NaN   
    10679                       Organic Coconut Flour      NaN   
    10706                                Multi-Cooker      NaN   
    10709                    Almond Flour Pancake Mix      NaN   
    10790                             Spicy BBQ Sauce      NaN   
    10857              Cat Tree with Scratching Posts      NaN   
    10858                                Multi-Cooker      NaN   
    10924                       Organic Coconut Flour      NaN   
    10940                             Spicy BBQ Sauce      NaN   
    10984                                Multi-Cooker      NaN   
    
                       Sub-Category   Sales  Cost Price  Quantity  Discount  
    41                       Cheese    4.99       1.497         6      0.27  
    152         Portable Projectors   29.99       8.997         3      0.40  
    187            Chocolate Snacks    3.49       1.047        18      0.32  
    192                       Candy    2.29       0.687         4      0.05  
    248                 Herb Blends    1.99       0.597        10      0.38  
    334                 Herb Blends    1.99       0.597        15      0.40  
    377                 Herb Blends    1.99       0.597        18      0.39  
    405         Kitchen Accessories   12.99       3.897         7      0.33  
    443                       Candy    2.29       0.687        12      0.12  
    487           Camping Equipment   19.99       5.997        18      0.00  
    594                      Cheese    4.99       1.497         5      0.00  
    650                 Herb Blends    1.99       0.597        13      0.29  
    654           Wireless Speakers   69.99      20.997         6      0.08  
    659            Small Appliances   49.99      14.997        20      0.21  
    691         Portable Projectors   29.99       8.997        12      0.17  
    750           Wireless Speakers   69.99      20.997         3      0.03  
    762         Portable Projectors   29.99       8.997        13      0.21  
    796                 Herb Blends    1.99       0.597         9      0.39  
    813           Wireless Speakers   69.99      20.997         8      0.37  
    911         Portable Projectors   29.99       8.997        10      0.32  
    938                      Cheese    4.99       1.497         2      0.07  
    943                     Bottoms   34.99      10.497        15      0.27  
    988             Seasoning Mixes    2.99       0.897        19      0.07  
    1004                    Poultry    9.99       3.996         9      0.07  
    1111               Dog Supplies   14.99       5.996         2      0.40  
    1148     Automotive Accessories   14.99       4.497         7      0.24  
    1231         Sleep & Relaxation   79.99      31.996         5      0.28  
    1272         Sleep & Relaxation   79.99      31.996         9      0.07  
    1396            Storage Devices    9.99       2.997        16      0.03  
    1469    Audio Recording Devices   49.99      19.996         2      0.14  
    1587              Health Drinks    5.99       2.396         2      0.18  
    1625                    Poultry    9.99       3.996        12      0.35  
    1641                    Poultry    9.99       3.996         3      0.02  
    1885     Food Storage Solutions   18.99       7.596         7      0.10  
    2044             Smart Lighting   21.41       6.997        14      0.03  
    2054               Dog Supplies   16.41       6.996        10      0.19  
    2069         Sleep & Relaxation   81.41      32.996        16      0.05  
    2116     Food Storage Solutions   20.41       8.596        18      0.17  
    2127             Smart Lighting   21.41       6.997         4      0.04  
    2194             Smart Lighting   21.41       6.997        13      0.18  
    2278     Food Storage Solutions   20.41       8.596        10      0.04  
    2299     Automotive Accessories   16.41       5.497        16      0.08  
    2371     Food Storage Solutions   20.41       8.596        14      0.19  
    2378                    Poultry   11.41       4.996        12      0.16  
    2436         Outdoor Recreation   21.41       6.997         7      0.18  
    2461             Granola/Cereal    6.41       2.996         4      0.12  
    2571                    Poultry   11.41       4.996         2      0.06  
    2624                    Poultry   11.41       4.996        18      0.15  
    2631             Smart Lighting   21.41       6.997         4      0.01  
    2731     Food Storage Solutions   20.41       8.596         2      0.07  
    2945              Health Drinks    7.41       3.396        13      0.10  
    3068         Cooking Appliances   89.99      26.997         8      0.16  
    3081         Cooking Appliances   89.99      26.997         3      0.40  
    3125               Seeds & Nuts    2.99       0.897        12      0.08  
    3220   Personal Care & Grooming   59.99      17.997         4      0.32  
    3288         Cooling Appliances  299.99      89.997         4      0.00  
    3320           Coffee Equipment   29.99       8.997        11      0.27  
    3444         Cooling Appliances  299.99      89.997         7      0.18  
    3488   Personal Care & Grooming   59.99      17.997        11      0.10  
    3586               Whole Grains    4.29       1.287        20      0.14  
    3598               Seeds & Nuts    2.99       0.897        20      0.00  
    3757               Seeds & Nuts    2.99       0.897         8      0.05  
    3892                      Mixes    5.99       1.797         2      0.07  
    3896              Cat Furniture   79.99      23.997        15      0.09  
    3901                      Mixes    5.99       1.797        16      0.16  
    4028               Dog Supplies   15.99       5.996         3      0.17  
    4195               Dog Supplies   15.99       5.996        10      0.17  
    4298         Outdoor Recreation   20.99       5.997         4      0.11  
    4383             Granola/Cereal    5.99       1.996         9      0.18  
    4441              Health Drinks    6.99       2.396         3      0.11  
    4476                    Poultry   10.99       3.996        16      0.16  
    4520                    Poultry   10.99       3.996        14      0.09  
    4641              Health Drinks    6.99       2.396        20      0.00  
    4652               Dog Supplies   15.99       5.996        17      0.16  
    4715                    Poultry   10.99       3.996        15      0.14  
    4865         Outdoor Recreation   20.99       5.997         8      0.16  
    4883     Food Storage Solutions   19.99       7.596        18      0.20  
    4891               Dog Supplies   15.99       5.996         7      0.16  
    5050                    Bottoms   33.99       9.947        20      0.07  
    5082            Seasoning Mixes    1.99       0.347        19      0.07  
    5098           Chocolate Snacks    2.49       0.497         9      0.13  
    5122          Wireless Speakers   68.99      20.447        18      0.15  
    5151           Chocolate Snacks    2.49       0.497         4      0.20  
    5201                    Bottoms   33.99       9.947        20      0.06  
    5282                    Bottoms   33.99       9.947         4      0.19  
    5375          Camping Equipment   18.99       5.447        13      0.19  
    5424           Small Appliances   48.99      14.447         3      0.00  
    5427          Wireless Speakers   68.99      20.447        19      0.04  
    5453                    Bottoms   33.99       9.947         5      0.00  
    5505           Small Appliances   48.99      14.447         9      0.15  
    5522                     Cheese    3.99       0.947        18      0.00  
    5542              Healthy Meals    4.99       1.247        18      0.27  
    5549           Chocolate Snacks    2.49       0.497        16      0.16  
    5660                      Candy    1.29       0.137         9      0.00  
    5679        Kitchen Accessories   11.99       3.347         4      0.34  
    5731            Seasoning Mixes    1.99       0.347         6      0.25  
    5775                     Cheese    3.99       0.947         3      0.36  
    5795                    Bottoms   33.99       9.947        15      0.12  
    5934                Herb Blends    0.99       0.047         4      0.21  
    5970            Seasoning Mixes    1.99       0.347         7      0.00  
    5979                      Candy    1.29       0.137        11      0.24  
    6089         Outdoor Recreation   19.14       5.497         2      0.22  
    6269    Audio Recording Devices   49.14      19.496        12      0.11  
    6316         Outdoor Recreation   19.14       5.497        17      0.17  
    6326    Audio Recording Devices   49.14      19.496         1      0.35  
    6428             Smart Lighting   19.14       5.497         8      0.27  
    6458             Granola/Cereal    4.14       1.496        18      0.31  
    6490             Granola/Cereal    4.14       1.496         1      0.27  
    6578             Granola/Cereal    4.14       1.496        13      0.34  
    6594    Audio Recording Devices   49.14      19.496        10      0.35  
    6648    Audio Recording Devices   49.14      19.496         3      0.24  
    6676    Audio Recording Devices   49.14      19.496         9      0.00  
    6746              Health Drinks    5.14       1.896         2      0.36  
    6846    Audio Recording Devices   49.14      19.496         3      0.38  
    6971             Smart Lighting   19.14       5.497         6      0.14  
    7019              Cat Furniture   79.14      23.497         9      0.05  
    7021   Personal Care & Grooming   59.14      17.497        18      0.01  
    7038         Cooling Appliances  299.14      89.497         1      0.00  
    7170                 Herbal Tea    2.44       0.487         1      0.13  
    7236                 Herbal Tea    2.44       0.487         6      0.08  
    7246         Cooking Appliances   89.14      26.497        14      0.00  
    7279   Personal Care & Grooming   59.14      17.497         4      0.35  
    7282        Outdoor Accessories   49.14      14.497         6      0.34  
    7289         Baking Ingredients    4.64       1.147         2      0.28  
    7298                 Herbal Tea    2.44       0.487         5      0.20  
    7378               Seeds & Nuts    2.14       0.397         9      0.17  
    7442         Cooking Appliances   89.14      26.497        15      0.35  
    7498   Personal Care & Grooming   59.14      17.497        17      0.22  
    7552                     Sauces    3.14       0.697         1      0.19  
    7553        Outdoor Accessories   49.14      14.497        15      0.13  
    7559               Seeds & Nuts    2.14       0.397         1      0.02  
    7570         Cooking Appliances   89.14      26.497         4      0.00  
    7581               Whole Grains    3.44       0.787         4      0.14  
    7778              Cat Furniture   79.14      23.497         3      0.36  
    7810                     Sauces    3.14       0.697        18      0.16  
    7911         Cooking Appliances   89.14      26.497        18      0.18  
    7986                 Herbal Tea    2.44       0.487        15      0.11  
    7996               Seeds & Nuts    2.14       0.397        11      0.37  
    7997         Baking Ingredients    4.64       1.147        19      0.37  
    8096              Health Drinks    5.24       2.146        15      0.00  
    8098     Automotive Accessories   14.24       4.247        16      0.07  
    8211     Automotive Accessories   14.24       4.247         7      0.04  
    8375                    Poultry    9.24       3.746         7      0.04  
    8512         Outdoor Recreation   19.24       5.747        16      0.03  
    8564     Automotive Accessories   14.24       4.247        15      0.01  
    8616             Granola/Cereal    4.24       1.746         6      0.07  
    8620             Smart Lighting   19.24       5.747        14      0.07  
    8632               Dog Supplies   14.24       5.746        18      0.07  
    8691               Dog Supplies   14.24       5.746        12      0.00  
    8861               Dog Supplies   14.24       5.746        10      0.00  
    8937                    Poultry    9.24       3.746        12      0.08  
    9042         Cooking Appliances   89.99      26.997         2      0.38  
    9086         Cooking Appliances   89.99      26.997         4      0.07  
    9154        Outdoor Accessories   49.99      14.997        17      0.38  
    9243               Seeds & Nuts    2.99       0.897         5      0.00  
    9276               Seeds & Nuts    2.99       0.897         4      0.29  
    9332              Cat Furniture   79.99      23.997        17      0.29  
    9341        Outdoor Accessories   49.99      14.997        14      0.11  
    9485           Coffee Equipment   29.99       8.997         6      0.12  
    9493         Baking Ingredients    5.49       1.647         4      0.12  
    9564                   Mustards    3.49       1.047        10      0.09  
    9608               Seeds & Nuts    2.99       0.897        12      0.33  
    9619                 Herbal Tea    3.29       0.987         6      0.00  
    9629         Cooking Appliances   89.99      26.997         5      0.16  
    9685                      Mixes    5.99       1.797        12      0.26  
    9686               Seeds & Nuts    2.99       0.897         6      0.04  
    9800                   Mustards    3.49       1.047         8      0.13  
    9851         Cooling Appliances  299.99      89.997        10      0.26  
    9860               Whole Grains    4.29       1.287         3      0.20  
    9893              Cat Furniture   79.99      23.997         6      0.11  
    9917                     Sauces    3.99       1.197         3      0.00  
    9991   Personal Care & Grooming   59.99      17.997        11      0.01  
    9995         Cooling Appliances  299.99      89.997         3      0.35  
    10018        Cooking Appliances   89.99      26.997        18      0.35  
    10027        Cooling Appliances  299.99      89.997        13      0.23  
    10172  Personal Care & Grooming   59.99      17.997         5      0.25  
    10181        Cooling Appliances  299.99      89.997        16      0.19  
    10189              Whole Grains    4.29       1.287        15      0.26  
    10225              Whole Grains    4.29       1.287        13      0.26  
    10315                Herbal Tea    3.29       0.987        20      0.29  
    10331                    Sauces    3.99       1.197         4      0.29  
    10377                Herbal Tea    3.29       0.987        11      0.15  
    10451       Outdoor Accessories   49.99      14.997         6      0.16  
    10534                  Mustards    3.49       1.047        20      0.10  
    10549  Personal Care & Grooming   59.99      17.997        17      0.40  
    10628  Personal Care & Grooming   59.99      17.997        15      0.28  
    10640       Outdoor Accessories   49.99      14.997        11      0.23  
    10650        Cooling Appliances  299.99      89.997        16      0.12  
    10657          Coffee Equipment   29.99       8.997        17      0.07  
    10679        Baking Ingredients    5.49       1.647        14      0.06  
    10706        Cooking Appliances   89.99      26.997        11      0.01  
    10709                     Mixes    5.99       1.797         2      0.00  
    10790                    Sauces    3.99       1.197        15      0.25  
    10857             Cat Furniture   79.99      23.997        19      0.31  
    10858        Cooking Appliances   89.99      26.997         1      0.16  
    10924        Baking Ingredients    5.49       1.647        14      0.04  
    10940                    Sauces    3.99       1.197        14      0.13  
    10984        Cooking Appliances   89.99      26.997        19      0.09  
    


```python
sns.histplot(df['Category'])
```




    <Axes: xlabel='Category', ylabel='Count'>




    
![png](output_12_1.png)
    



```python
#here I am going  to see number of unique categories
# Create a DataFrame with unique (Sub-Category, Category) pairs after dropping missing categories
subcat_to_cat = df[['Sub-Category', 'Category']].dropna().drop_duplicates()

# Group by Sub-Category and count how many unique Categories each one maps to
mapping_check = subcat_to_cat.groupby('Sub-Category')['Category'].nunique()

# Print Sub-Categories that are mapped to more than 1 Category (inconsistent mapping)
print(mapping_check[mapping_check > 1])

```

    Sub-Category
    Accessories                4
    Activewear                 2
    Asian Sauces               2
    Bags                       2
    Baking Ingredients         3
    Baking Mixes               2
    Camera Accessories         2
    Canned Fruits              2
    Casual Footwear            2
    Condiments                 3
    Cookies                    3
    Cooking Oils               2
    Desserts                   3
    Dips and Spreads           2
    Dried Fruits               2
    Frozen Appetizers          3
    Frozen Fruits              5
    Frozen Meals               4
    Frozen Pasta Dishes        2
    Frozen Snacks              3
    Frozen Vegetables          2
    Frozen Vegetarian Meals    2
    Fruits                     2
    Garden Supplies            2
    Granola                    2
    Healthy Snacks             2
    Kitchen Accessories        2
    Laptop Accessories         2
    Leggings                   2
    Legumes                    2
    Marinades                  2
    Marinades and Sauces       2
    Meal Kits                  2
    Meat Alternatives          2
    Meat Products              2
    Mobile Accessories         2
    Noodles                    2
    Nut Butters                2
    Oils                       2
    Pasta                      2
    Plant-Based Proteins       2
    Protein Snacks             2
    Rice                       2
    Salads                     2
    Savory Snacks              2
    Seasoning Blends           2
    Snacks                     2
    Superfoods                 2
    Sweaters                   2
    Travel Accessories         2
    Vegetable Sides            2
    Vegetable Snacks           2
    Vegetables                 3
    Vegetarian Meals           2
    Wallets                    2
    Women's Footwear           2
    Name: Category, dtype: int64
    


```python
# Check unique category per sub-category
subcat_to_cat = df[['Sub-Category', 'Category']].dropna().drop_duplicates()

# Group to see how many unique categories exist per sub-category
mapping_check = subcat_to_cat.groupby('Sub-Category')['Category'].nunique()

print(mapping_check[mapping_check > 1])  # See if any sub-categories have more than 1 category

```

    Sub-Category
    Accessories                4
    Activewear                 2
    Asian Sauces               2
    Bags                       2
    Baking Ingredients         3
    Baking Mixes               2
    Camera Accessories         2
    Canned Fruits              2
    Casual Footwear            2
    Condiments                 3
    Cookies                    3
    Cooking Oils               2
    Desserts                   3
    Dips and Spreads           2
    Dried Fruits               2
    Frozen Appetizers          3
    Frozen Fruits              5
    Frozen Meals               4
    Frozen Pasta Dishes        2
    Frozen Snacks              3
    Frozen Vegetables          2
    Frozen Vegetarian Meals    2
    Fruits                     2
    Garden Supplies            2
    Granola                    2
    Healthy Snacks             2
    Kitchen Accessories        2
    Laptop Accessories         2
    Leggings                   2
    Legumes                    2
    Marinades                  2
    Marinades and Sauces       2
    Meal Kits                  2
    Meat Alternatives          2
    Meat Products              2
    Mobile Accessories         2
    Noodles                    2
    Nut Butters                2
    Oils                       2
    Pasta                      2
    Plant-Based Proteins       2
    Protein Snacks             2
    Rice                       2
    Salads                     2
    Savory Snacks              2
    Seasoning Blends           2
    Snacks                     2
    Superfoods                 2
    Sweaters                   2
    Travel Accessories         2
    Vegetable Sides            2
    Vegetable Snacks           2
    Vegetables                 3
    Vegetarian Meals           2
    Wallets                    2
    Women's Footwear           2
    Name: Category, dtype: int64
    


```python
subcat_to_cat_dict = subcat_to_cat.set_index('Sub-Category')['Category'].to_dict()

```


```python
df['Category'] = df.apply(
    lambda row: subcat_to_cat_dict[row['Sub-Category']] if pd.isna(row['Category']) else row['Category'],
    axis=1
)

```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    Cell In[17], line 1
    ----> 1 df['Category'] = df.apply(
          2     lambda row: subcat_to_cat_dict[row['Sub-Category']] if pd.isna(row['Category']) else row['Category'],
          3     axis=1
          4 )
    

    File ~\AppData\Local\anaconda3\Lib\site-packages\pandas\core\frame.py:10374, in DataFrame.apply(self, func, axis, raw, result_type, args, by_row, engine, engine_kwargs, **kwargs)
      10360 from pandas.core.apply import frame_apply
      10362 op = frame_apply(
      10363     self,
      10364     func=func,
       (...)
      10372     kwargs=kwargs,
      10373 )
    > 10374 return op.apply().__finalize__(self, method="apply")
    

    File ~\AppData\Local\anaconda3\Lib\site-packages\pandas\core\apply.py:916, in FrameApply.apply(self)
        913 elif self.raw:
        914     return self.apply_raw(engine=self.engine, engine_kwargs=self.engine_kwargs)
    --> 916 return self.apply_standard()
    

    File ~\AppData\Local\anaconda3\Lib\site-packages\pandas\core\apply.py:1063, in FrameApply.apply_standard(self)
       1061 def apply_standard(self):
       1062     if self.engine == "python":
    -> 1063         results, res_index = self.apply_series_generator()
       1064     else:
       1065         results, res_index = self.apply_series_numba()
    

    File ~\AppData\Local\anaconda3\Lib\site-packages\pandas\core\apply.py:1081, in FrameApply.apply_series_generator(self)
       1078 with option_context("mode.chained_assignment", None):
       1079     for i, v in enumerate(series_gen):
       1080         # ignore SettingWithCopy here in case the user mutates
    -> 1081         results[i] = self.func(v, *self.args, **self.kwargs)
       1082         if isinstance(results[i], ABCSeries):
       1083             # If we have a view on v, we need to make a copy because
       1084             #  series_generator will swap out the underlying data
       1085             results[i] = results[i].copy(deep=False)
    

    Cell In[17], line 2, in <lambda>(row)
          1 df['Category'] = df.apply(
    ----> 2     lambda row: subcat_to_cat_dict[row['Sub-Category']] if pd.isna(row['Category']) else row['Category'],
          3     axis=1
          4 )
    

    KeyError: 'Seasoning Mixes'



```python
# Step 1: Build mapping from complete (non-null) Category & Sub-Category rows
subcat_to_cat = df[['Sub-Category', 'Category']].dropna().drop_duplicates()
subcat_to_cat_dict = subcat_to_cat.set_index('Sub-Category')['Category'].to_dict()

# Step 2: Impute missing values using the mapping — safely!
def impute_category(row):
    if pd.isna(row['Category']):
        return subcat_to_cat_dict.get(row['Sub-Category'], None)  # returns None if not found
    return row['Category']

df['Category'] = df.apply(impute_category, axis=1)

```


```python
missing_after = df[df['Category'].isna()]
print(f"Still missing: {len(missing_after)} rows")
print(missing_after[['Sub-Category', 'Category']].drop_duplicates())

```

    Still missing: 31 rows
                     Sub-Category Category
    988           Seasoning Mixes     None
    1111             Dog Supplies     None
    1469  Audio Recording Devices     None
    3125             Seeds & Nuts     None
    5542            Healthy Meals     None
    


```python
# Define manual mapping
manual_map = {
    'Seasoning Mixes': 'Food - Condiments',
    'Dog Supplies': 'Pet Supplies',
    'Audio Recording Devices': 'Electronics',
    'Seeds & Nuts': 'Food - Snacks',
    'Healthy Meals': 'Food - Meal Kits'
}

# Apply mapping
df['Category'] = df.apply(
    lambda row: manual_map.get(row['Sub-Category'], row['Category']) if pd.isna(row['Category']) else row['Category'],
    axis=1
)

```


```python
print("Still missing categories:", df['Category'].isna().sum())

```

    Still missing categories: 0
    


```python
df['Revenue']=df['Quantity']*df['Cost Price']
summery=df.groupby(['Region','Order Mode']).agg(
    Total_Sales=('Sales','sum'),
    Total_Revenue=('Revenue','sum'),
    Average_Discount=('Discount','mean'),
    Total_Orders=('Order ID','count')
).reset_index()
print(summery)
```

                          Region Order Mode  Total_Sales  Total_Revenue  \
    0              East Midlands   In-Store     13876.79      46912.469   
    1              East Midlands     Online     11174.92      38371.741   
    2            East of England   In-Store      9964.54      36188.845   
    3            East of England     Online     12892.39      45464.648   
    4                     London   In-Store     11397.99      40958.777   
    5                     London     Online     12141.37      42282.440   
    6                 North East   In-Store     12413.27      43812.584   
    7                 North East     Online     13305.55      46494.823   
    8                 North West   In-Store     11942.37      37837.628   
    9                 North West     Online     12702.10      40856.786   
    10                South East   In-Store     13973.75      53368.227   
    11                South East     Online     11928.76      42547.048   
    12                South West   In-Store     10237.77      37403.778   
    13                South West     Online     12216.06      39029.023   
    14             West Midlands   In-Store     13651.19      49191.350   
    15             West Midlands     Online     11871.33      39221.597   
    16  Yorkshire and the Humber   In-Store     12411.64      43065.178   
    17  Yorkshire and the Humber     Online     14967.23      58487.225   
    18                   unknown   In-Store     35877.32     118454.812   
    19                   unknown     Online     42387.61     144109.305   
    
        Average_Discount  Total_Orders  
    0           0.163550           524  
    1           0.162883           437  
    2           0.162000           425  
    3           0.141618           482  
    4           0.156076           446  
    5           0.164800           425  
    6           0.158052           426  
    7           0.151788           481  
    8           0.149058           446  
    9           0.160417           480  
    10          0.160118           425  
    11          0.164772           438  
    12          0.163450           429  
    13          0.156116           484  
    14          0.156455           440  
    15          0.154228           492  
    16          0.159668           422  
    17          0.161992           487  
    18          0.149813          1335  
    19          0.156612          1476  
    


```python
import matplotlib.pyplot as plt
import seaborn as sns

# Set the style
sns.set(style="whitegrid")

# Plot
plt.figure(figsize=(12, 6))
sns.barplot(
    data=summery,
    x='Region',
    y='Total_Sales',
    hue='Order Mode'
)

# Customize the plot
plt.title('Total Sales by Region and Order Mode')
plt.xticks(rotation=45)
plt.ylabel('Total Sales (£)')
plt.xlabel('Region')
plt.legend(title='Order Mode')
plt.tight_layout()

# Show the plot
plt.show()

```


    
![png](output_22_0.png)
    



```python
import pandas as pd

# Make sure Revenue column exists
df['Revenue'] = df['Quantity'] * df['Cost Price']

# Group by Product Name and sum the revenue
product_revenue = df.groupby('Product Name')['Revenue'].sum().reset_index()

# Sort to get top 5 best-selling
top_5_products = product_revenue.sort_values(by='Revenue', ascending=False).head(5)

# Sort to get bottom 5 underperforming
bottom_5_products = product_revenue.sort_values(by='Revenue', ascending=True).head(5)

# Display results
print(" Top 5 Best-Selling Products by Revenue:")
print(top_5_products)

print("\n Bottom 5 Underperforming Products by Revenue:")
print(bottom_5_products)

```

     Top 5 Best-Selling Products by Revenue:
                           Product Name    Revenue
    484                   Electric Bike  19073.788
    1200  Portable Refrigerator Freezer  15419.237
    1204       Portable Solar Generator  15345.116
    363          Compact Digital Camera  13309.468
    443                  Digital Camera  12840.322
    
     Bottom 5 Underperforming Products by Revenue:
                    Product Name  Revenue
    1081            Peach Yogurt   -2.243
    87               Baking Soda   -0.892
    1554            Tomato Paste    1.323
    297   Cinnamon Raisin Bagels    1.414
    180          Cajun Seasoning    1.974
    


```python
import seaborn as sns
import matplotlib.pyplot as plt

# Plot Top 5 Best-Selling Products
plt.figure(figsize=(10, 5))
sns.barplot(
    data=top_5_products,
    x='Revenue',
    y='Product Name',
    palette='Greens_r'
)
plt.title('Top 5 Best-Selling Products by Revenue')
plt.xlabel('Revenue (£)')
plt.ylabel('Product Name')
plt.tight_layout()
plt.show()

# Plot Bottom 5 Underperforming Products
plt.figure(figsize=(10, 5))
sns.barplot(
    data=bottom_5_products,
    x='Revenue',
    y='Product Name',
    palette='Reds_r'
)
plt.title(' Bottom 5 Underperforming Products by Revenue')
plt.xlabel('Revenue (£)')
plt.ylabel('Product Name')
plt.tight_layout()
plt.show()

```

    C:\Users\murta\AppData\Local\Temp\ipykernel_8108\997102584.py:6: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(
    


    
![png](output_24_1.png)
    


    C:\Users\murta\AppData\Local\Temp\ipykernel_8108\997102584.py:20: FutureWarning: 
    
    Passing `palette` without assigning `hue` is deprecated and will be removed in v0.14.0. Assign the `y` variable to `hue` and set `legend=False` for the same effect.
    
      sns.barplot(
    


    
![png](output_24_3.png)
    



```python


# Step 1: Calculate profit and margin
df['Profit'] = df['Sales'] - df['Cost Price'] * df['Quantity']
df['Margin (%)'] = (df['Profit'] / df['Sales']) * 100

# Step 2: Group by Category and summarize
category_margin = df.groupby('Category').agg(
    Total_Sales=('Sales', 'sum'),
    Total_Cost=('Cost Price', lambda x: (x * df.loc[x.index, 'Quantity']).sum()),
    Total_Profit=('Profit', 'sum'),
    Average_Margin_Percent=('Margin (%)', 'mean')
).reset_index()

# Sort by margin
category_margin_sorted = category_margin.sort_values(by='Average_Margin_Percent', ascending=False)

# Display result
print(category_margin_sorted)

```

                          Category  Total_Sales  Total_Cost  Total_Profit  \
    58             Food - Dressing         7.17      10.741        -3.571   
    95              Food - Protein        17.71      36.174       -18.464   
    89      Food - Oils & Vinegars        89.76     186.384       -96.624   
    43         Food - Canned Soups        91.44     221.501      -130.061   
    44               Food - Cereal       122.03     297.023      -174.993   
    104              Food - Spices       179.65     458.820      -279.170   
    41      Food - Breakfast Foods        37.34      89.723       -52.383   
    96       Food - Salad Toppings         9.96      25.024       -15.064   
    23            Clothing - Shoes      1115.58    2797.580     -1682.000   
    90               Food - Pantry        35.90      88.314       -52.414   
    100          Food - Seasonings        24.62      63.103       -38.483   
    51         Food - Cooking Oils        23.95      59.421       -35.471   
    105             Food - Spreads        17.26      38.656       -21.396   
    64      Food - Frozen Desserts       181.27     471.116      -289.846   
    129                    Storage      1058.13    3032.062     -1973.932   
    106         Food - Supplements       191.89     461.556      -269.666   
    117           Home Improvement       876.50    2058.238     -1181.738   
    94              Food - Produce       543.51    1854.619     -1311.109   
    108          Food - Vegetarian        19.71      51.792       -32.082   
    72          Food - Grab-and-Go        41.08     111.711       -70.631   
    36     Food - Baking & Cooking        69.80     196.488      -126.688   
    86                Food - Meats        70.96     194.795      -123.835   
    67        Food - Frozen Fruits        48.42     132.494       -84.074   
    78       Food - Jams & Jellies        27.87      77.852       -49.982   
    79            Food - Marinades        20.74      58.505       -37.765   
    48        Food - Confectionery        52.13     155.246      -103.116   
    98               Food - Sauces       344.73    1119.835      -775.105   
    16          Clothing - Dresses      1664.03    4854.058     -3190.028   
    35               Food - Baking       798.65    2419.279     -1620.629   
    42         Food - Canned Goods       681.72    2159.887     -1478.167   
    73               Food - Grains       472.19    1463.477      -991.287   
    61              Food - Freezer        34.74     103.955       -69.215   
    12       Clothing - Activewear      2028.76    6058.344     -4029.584   
    52                Food - Dairy       769.19    2519.772     -1750.582   
    101               Food - Sides       129.04     419.496      -290.456   
    68         Food - Frozen Meals       495.88    1691.434     -1195.554   
    91                Food - Pasta       287.97    1039.929      -751.959   
    83       Food - Meat & Seafood        34.08     102.281       -68.201   
    21            Clothing - Pants      1271.81    3835.421     -2563.611   
    17         Clothing - Footwear      2314.16    6600.334     -4286.174   
    92       Food - Prepared Foods       511.89    1532.403     -1020.513   
    85     Food - Meat Substitutes        51.41     155.792      -104.382   
    84    Food - Meat Alternatives        59.68     164.243      -104.563   
    33          Food - Baked Goods        67.26     216.561      -149.301   
    37         Food - Baking Goods       164.92     558.939      -394.019   
    53   Food - Dairy Alternatives        88.32     273.612      -185.292   
    34               Food - Bakery       838.79    2709.423     -1870.633   
    102              Food - Snacks      2914.44    9378.166     -6463.726   
    87                 Food - Nuts       181.65     561.066      -379.416   
    59            Food - Dressings        68.32     219.314      -150.994   
    20        Clothing - Outerwear      6747.17   21415.053    -14667.883   
    38            Food - Beverages      1199.20    3957.758     -2758.558   
    99              Food - Seafood       775.70    2599.718     -1824.018   
    118              Home Security      2798.68    9274.649     -6475.969   
    132                     Travel      1413.67    4497.345     -3083.675   
    24           Clothing - Skirts       196.95     628.038      -431.088   
    70               Food - Fruits        81.82     281.446      -199.626   
    5                         Baby       516.73    1861.956     -1345.226   
    39                Food - Bread        24.26      78.385       -54.125   
    47           Food - Condiments      2056.18    7015.696     -4959.516   
    25         Clothing - Sweaters       710.72    2333.700     -1622.980   
    63               Food - Frozen       586.97    2013.264     -1426.294   
    50          Food - Cooking Oil        69.74     227.496      -157.756   
    124                       Pets     11503.22   37546.451    -26043.231   
    10                    Clothing      2386.42    7632.594     -5246.174   
    0                  Accessories      5744.94   19821.730    -14076.790   
    40            Food - Breakfast       613.73    2063.794     -1450.064   
    121                     Office      7719.30   22144.241    -14424.941   
    130                      Tools      2261.04    8371.467     -6110.427   
    54                 Food - Deli        54.40     199.774      -145.374   
    97               Food - Salads       541.21    1872.760     -1331.550   
    4                   Automotive      2520.09    8443.279     -5923.189   
    66         Food - Frozen Foods      1736.15    5900.470     -4164.320   
    57                 Food - Dips        76.75     267.560      -190.810   
    103               Food - Soups       275.14     963.180      -688.040   
    6                     Bathroom       662.14    2244.177     -1582.037   
    133              Wearable Tech      2376.39    8589.286     -6212.896   
    127                 Smart Home      4234.79   15070.448    -10835.658   
    74              Food - Grocery        80.07     274.356      -194.286   
    80            Food - Meal Kits       177.45     614.092      -436.642   
    114                     Health     10792.52   37616.096    -26823.576   
    119                    Kitchen     36046.21  121986.626    -85940.416   
    46               Food - Cheese       164.49     573.100      -408.610   
    30                 Electronics     22268.58   75234.560    -52965.980   
    56             Food - Desserts       154.93     537.296      -382.366   
    107          Food - Vegetables       155.18     560.283      -405.103   
    115                       Home     21512.51   73135.235    -51622.725   
    9                        Books      1142.12    3982.988     -2840.868   
    22           Clothing - Shirts      1704.34    5955.096     -4250.756   
    126                     Safety       450.75    1571.695     -1120.945   
    81                 Food - Meat      1778.13    6244.836     -4466.706   
    122                    Outdoor     35187.50  122985.729    -87798.229   
    116            Home Appliances     14257.40   48301.505    -34044.105   
    60         Food - Dried Fruits        64.31     221.488      -157.178   
    18        Clothing - Jumpsuits      1393.95    5091.725     -3697.775   
    62        Food - Fresh Produce        75.73     193.017      -117.287   
    112                     Garden      6082.24   21391.823    -15309.583   
    27             Clothing - Tops      2598.12    9245.466     -6647.346   
    31                     Fitness     14048.88   50195.584    -36146.704   
    111                     Gaming      2874.08   12309.848     -9435.768   
    88                 Food - Oils       187.80     680.431      -492.631   
    131                       Toys      6694.59   24515.462    -17820.872   
    65          Food - Frozen Food       334.65    1210.119      -875.469   
    11      Clothing - Accessories      1704.12    6298.671     -4594.551   
    29                      Crafts       902.26    2777.839     -1875.579   
    120                      Music      4100.03   14208.378    -10108.348   
    3                        Audio      6093.42   22046.214    -15952.794   
    55           Food - Deli Meats        29.12     114.124       -85.004   
    14          Clothing - Bottoms      3188.95   12163.522     -8974.572   
    13             Clothing - Bags       270.22    1020.886      -750.666   
    8                     Bicycles      4850.32   20366.887    -15516.567   
    93       Food - Prepared Meals       544.07    2112.548     -1568.478   
    123               Pet Supplies       138.08     533.644      -395.564   
    69    Food - Frozen Vegetables       140.54     534.466      -393.926   
    125                Photography      5375.13   22107.407    -16732.277   
    7                       Beauty      2809.66   10720.079     -7910.419   
    28                   Computers       781.62    3031.028     -2249.408   
    32                        Food       356.44    1250.609      -894.169   
    128                     Sports       287.86    1136.559      -848.699   
    45              Food - Cereals        84.92     331.308      -246.388   
    19       Clothing - Loungewear       471.30    1879.637     -1408.337   
    2                 Art Supplies      2044.42    7973.229     -5928.809   
    1                         Apps       179.69     737.462      -557.772   
    26         Clothing - Swimwear       151.35     626.788      -475.438   
    49         Food - Cooking Kits        39.11     165.832      -126.722   
    71         Food - Gourmet Rice        20.04      90.774       -70.734   
    109                   Footwear      1435.40    6328.796     -4893.396   
    75         Food - Health Foods        47.34     226.308      -178.968   
    82       Food - Meat & Poultry        84.57     413.466      -328.896   
    113                   Grooming        68.98     335.951      -266.971   
    110                  Furniture      2848.85   14031.704    -11182.854   
    77            Food - Household       124.24     627.194      -502.954   
    15            Clothing - Coats       652.20    3584.724     -2932.524   
    76       Food - Health/Protein       151.66     952.120      -800.460   
    
         Average_Margin_Percent  
    58               -49.804742  
    95               -92.063679  
    89              -124.691426  
    43              -135.167569  
    44              -139.512378  
    104             -140.234782  
    41              -140.570934  
    96              -142.763819  
    23              -145.752358  
    90              -146.000000  
    100             -146.198770  
    51              -146.721805  
    105             -148.871370  
    64              -153.556499  
    129             -155.934739  
    106             -157.838477  
    117             -160.582719  
    94              -161.353609  
    108             -166.044304  
    72              -167.957198  
    36              -168.015200  
    86              -172.479710  
    67              -174.045091  
    78              -176.058394  
    79              -183.183990  
    48              -186.484324  
    98              -187.787197  
    16              -191.555489  
    35              -193.320124  
    42              -195.993919  
    73              -197.236965  
    61              -198.219912  
    12              -198.285607  
    52              -198.523215  
    101             -199.568266  
    68              -200.103102  
    91              -200.986498  
    83              -201.021394  
    21              -202.004395  
    17              -202.505774  
    92              -202.952762  
    85              -204.413271  
    84              -206.461548  
    33              -207.086701  
    37              -208.037653  
    53              -209.116477  
    34              -210.537632  
    102             -210.842338  
    87              -213.026339  
    59              -213.704522  
    20              -214.010164  
    38              -214.431411  
    99              -217.422450  
    118             -218.816103  
    132             -218.965163  
    24              -219.383432  
    70              -220.885232  
    5               -223.145893  
    39              -223.339061  
    47              -223.955055  
    25              -228.905931  
    63              -231.712755  
    50              -231.851497  
    124             -231.931849  
    10              -232.416585  
    0               -233.052568  
    40              -234.484090  
    121             -235.921670  
    130             -236.547409  
    54              -236.621156  
    97              -236.681183  
    4               -237.049808  
    66              -237.271379  
    57              -237.336254  
    103             -238.208712  
    6               -238.423985  
    133             -239.452727  
    127             -239.534686  
    74              -240.200611  
    80              -241.440010  
    114             -243.348447  
    119             -244.309342  
    46              -244.824338  
    30              -245.156133  
    56              -245.602661  
    107             -246.791362  
    115             -247.316447  
    9               -247.465169  
    22              -248.469267  
    126             -249.869856  
    81              -251.549953  
    122             -252.108932  
    116             -252.273535  
    60              -252.392337  
    18              -254.113890  
    62              -255.081396  
    112             -256.390327  
    27              -257.006813  
    31              -258.994106  
    111             -260.635668  
    88              -261.491336  
    131             -262.208161  
    65              -262.935434  
    11              -263.322119  
    29              -266.697415  
    120             -266.920042  
    3               -269.639371  
    55              -274.186278  
    14              -279.418593  
    13              -279.593433  
    8               -285.864740  
    93              -288.321196  
    123             -289.756945  
    69              -291.925023  
    125             -292.193244  
    7               -292.754186  
    28              -293.044768  
    32              -294.873037  
    128             -295.889223  
    45              -301.531963  
    19              -303.323475  
    2               -306.859308  
    1               -311.265757  
    26              -313.860887  
    49              -317.319475  
    71              -338.907299  
    109             -339.589582  
    75              -370.780244  
    82              -386.435256  
    113             -388.012651  
    110             -397.507025  
    77              -419.461711  
    15              -449.833136  
    76              -525.325267  
    


```python
import pandas as pd

# Group by 'Order Mode' to summarize sales
order_mode_sales = df.groupby('Order Mode').agg(
    Total_Sales=('Sales', 'sum'),
    Average_Sales=('Sales', 'mean'),
    Number_of_Orders=('Order ID', 'count')
).reset_index()

print(order_mode_sales)

```

      Order Mode  Total_Sales  Average_Sales  Number_of_Orders
    0   In-Store    145746.63      27.406286              5318
    1     Online    155587.32      27.382492              5682
    


```python
import matplotlib.pyplot as plt

plt.figure(figsize=(6, 6))
plt.pie(order_mode_sales['Total_Sales'], labels=order_mode_sales['Order Mode'],
        autopct='%1.1f%%', startangle=140, colors=['#66b3ff','#99ff99'])
plt.title('💼 Sales Distribution by Order Mode')
plt.axis('equal')
plt.show()

```

    C:\Users\murta\AppData\Local\anaconda3\Lib\site-packages\IPython\core\pylabtools.py:170: UserWarning: Glyph 128188 (\N{BRIEFCASE}) missing from font(s) Arial.
      fig.canvas.print_figure(bytes_io, **kw)
    


    
![png](output_27_1.png)
    

